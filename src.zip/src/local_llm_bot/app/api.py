# Version: 1.10.11
# Changelog: 1.10.11 — AIS (2026-06-18): metadata-writer durability — the post-ingest (≈1470)
#            and delete-file (≈2253) writers now emit the `# <corpus>_corpus_metadata.yaml`
#            header + sort_keys=False, matching the upload/edit/reingest writers. Stops key
#            re-alphabetization + header loss on every ingest/delete (no curated-field churn).
# Changelog: 1.10.10 — AIS_27 (2026-06-15): migrated the deprecated @app.on_event("shutdown")
#            to a FastAPI lifespan context manager (FastAPI(lifespan=...)). Kills the two
#            on_event DeprecationWarnings; shutdown-trace behavior unchanged.
# Changelog: 1.10.9 — AIS_02: scope the removed-bracket whitespace tidy to [ \t]+ (spaces/tabs)
#            so it never collapses newlines / paragraph breaks before punctuation.
# Changelog: 1.10.8 — AIS_31 (cont.): _remap now DROPS tokens not in appearance_order
#            (out-of-range / model-invented indices, e.g. "[5,6]" at top_k=5) instead of
#            keeping them verbatim, and removes a bracket that loses all tokens. Kills the
#            dangling-marker-with-no-REFERENCES-row desync; trailing-space tidy after removal.
# Changelog: 1.10.7 — lint (UP037): drop forward-ref quotes on _remap's re.Match[str] annotation.
# Changelog: 1.10.6 — AIS_31 (orphan/desynced citations on multi-cite, 2026-06-14): renumber
#            pass now parses every bracket's indices one-by-one (single AND multi like [1,2])
#            and remaps via a replacement callback. The prior single-bracket regex skipped
#            multi-cites → an index seen only inside a multi-cite was orphaned (REFERENCES row
#            with no marker) and the stale multi-cite mis-attributed. Predicate-based, no
#            placeholder-swap. Reproduced + fixed against the curl temp-0.9 case.
# Changelog: 1.10.5 — AIS_26 (path leak in answer prose, 2026-06-14): label LLM-context
#            sources by basename, not absolute path. The model echoes the source label it's
#            shown; the full path leaked raw filesystem roots (incl. the foreign ingest-time
#            /Users/<other>/...) into answer text. Citation metadata keeps full doc.source for
#            Source Dive. Pairs with 1.10.3's serve-time rebase (same root-portability theme).
# Changelog: 1.10.4 — AIS_25 (dangling page-bearing citations, 2026-06-14): normalize
#            "[N, p. X]" / "[N, page X]" / "[N, pp. X-Y]" → "[N]" before citation extraction.
#            Small models fold the page into the marker imitating the page-labeled context;
#            the pure-numeric extractor then dropped them, leaving dead markers in the text
#            and incomplete REFERENCES (one source cited at 3 pages rendered as 1 row). The
#            authoritative page comes from the (source,page) dedup (768), so the embedded
#            page is redundant. Multi-cite [2,3] untouched (no p./page token). Each distinct
#            (source,page) now renders its own row.
# Changelog: 1.10.3 — AIS_01 (citation Open ↗ 404, 2026-06-14): /source now rebases a
#            foreign/stale absolute source path onto the local repo. Citation `source`
#            paths are captured at ingest time and can carry another machine/user root
#            (seed corpora were ingested under /Users/janebarbero/...), so the raw path
#            failed .exists() → 404, and would also fail the repo/data security check.
#            Fix: if the raw path doesn't resolve, find its "data/corpora/..." tail and
#            re-root on _get_repo_root(). No frontend change, no re-ingest; fixes all
#            corpora's existing payloads. Falls through to the original 404 if no tail.
# Changelog: 1.10.2 — AIS_17 (backend-kill observability, 2026-06-14): added an @app.on_event
#            ("shutdown") handler that logs "[backend] shutdown — server stopping" to stderr, so a
#            backend stopped/killed (graceful SIGTERM) during a long ingest leaves a trace instead
#            of vanishing silently. Pairs with the lsof preflight in ais_ingest_*.sh. SIGKILL can't
#            be caught (won't fire). Note: on_event is deprecated — migrate to lifespan later.
# Changelog: 1.10.1 — Ingest-status freeze fix. In _stream_stderr, parse the [ingest]
#            file_complete:/normalizer: machine signals by SUBSTRING and BEFORE the tqdm-bar
#            (is_process_line) classification. pipeline.py renders a live tqdm bar even under
#            this api.py pipe; its carriage-return clear()/refresh() glues onto the front of the
#            newline-terminated structured line (no newline between bar refresh and the write),
#            so the delivered line is "…<bar redraw>…[ingest] file_complete: …". The prior
#            startswith("[ingest] …") checks then failed and the signal was silently dropped —
#            files_processed/elapsed/pct/normalizer_hits never advanced, so the UI bar crawled
#            then froze while chunks were really being written (curl-confirmed). Substring match +
#            the existing re.search regexes match through any bar prefix; hoisting above
#            is_process_line stops a glued line that also looks like a Process line from being
#            swallowed by the postfix branch. Consumer-side only — no change to the ingest
#            subprocess (operator-TTY path untouched). Cross-ref AIStudio_613 (file_complete
#            signal), AIStudio_722 (TTY-gate that left the bar rendering in pipe mode). PIPELINE
#            item to file at EOS. # Version reconciled 1.9.6 → 1.10.1 (changelog locus was already
#            at 1.10.0; this corrects the stale version line per the Python versioning convention).
# Changelog: 1.10.0 — AIStudio_882 (scope application): AskRequest + RetrieveRequest gain
#            allowed_source_paths (scope firm-boundary, OR over source_path substrings, ANDed
#            with the resolved entity_filter). Passed through /ask and /debug/retrieve to
#            retrieve(). Orthogonal to entity_filter_mode: scope bounds the firm-universe,
#            entity logic narrows within it. Default None = pre-1.10.0 behavior.
# Changelog: 1.9.6 — Fix ruff B008 in trigger_ingest: Body(default=None) in the arg default
#            tripped "no function call in argument defaults". Switched to the Annotated form
#            (body: Annotated[dict | None, Body()] = None). No behavior change.
# Changelog: 1.9.5 — AIStudio: per-file selective ingest. POST /corpus/{c}/ingest now accepts
#            optional body {"files": [...]}. When present, pre-scan + status totals reflect only
#            those files and the ingest subprocess is launched with --files, so ONLY the selected
#            files are (re-)embedded; all other files in uploads/ (indexed or parked) are untouched.
#            Body absent → legacy whole-corpus pass. _run_ingest_background(only_files=...) appends
#            --files. Enables tutorial "index one file at a time" + honest reingest-N denominators.
# Changelog: 1.9.4 — AIStudio_876: _detect_query_entities now delegates to rag_core._detect_entities —
#            expansion + filter share ONE GLEIF-sourced detector. api.py normalizer_entity alias map retired.
# Changelog: 1.9.3 — AIStudio_875 fix: _detect_query_entities word-boundary match (\\b) — token
#            "morgan" no longer falsely matches inside "jpmorgan" (false MORGAN STANLEY expansion).
# Changelog: 1.9.2 — AIStudio_876 lint fix: I001 sort rag_core import block (_resolve_entity_filter_tokens).
# Changelog: 1.9.1 — AIStudio_876: _auto_entity_filter now sources the canonical→source_path
#            token from the declared entity KB via rag_core._resolve_entity_filter_tokens
#            (scope_name-derived), replacing the ad-hoc filename-split map. Removes
#            _build_canonical_sourcepath_map + _CANONICAL_TO_SOURCEPATH_CACHE. Unifies
#            expansion + filter on one knowledge base.
# Changelog: 1.9.0 — AIStudio_875: --query-expansion + --entity-filter support. AskRequest gains
#            query_expansion:int (entity-name expansion repeat, 0=off) and entity_filter_mode:str
#            (none|yaml|auto). New _detect_query_entities (shared scan), _expand_query_entities now
#            takes repeat count, _auto_entity_filter + _build_canonical_sourcepath_map wire detected
#            entities into the Qdrant source_path filter (the F8 missing piece). Replaces bench --augment-from.
# Changelog: 1.8.7 — AIStudio_841: add retrieval_query + model_used to AskResponse;
#             add keywords to RetrieveRequest; return retrieval_query + min_score_used
#             from /debug/retrieve. Makes query augmentation visible in API responses.
# Changelog: 1.8.6 — AIStudio_839: wire temperature through AskRequest → generate_answer_with_citations
#             → ollama_generate. Previously temperature was in AskRequest but never passed
#             to the LLM — all runs used Ollama default temperature regardless of --temperature flag.
#             Also: firm/year confirmed absent from AskRequest (already placebo at API level,
#             AIStudio_589 — no change needed).
# Changelog: 1.8.5 — AIStudio_838: add model field to AskRequest; pass through to
#             ollama_generate. Previously model was silently ignored — all bench runs
#             used CONFIG.rag.default_model (llama3.1:8b) regardless of --model flag.
# Changelog: 1.8.4 — AIStudio_837: implicit citation fallback in generate_answer_with_citations.
#             When LLM omits [N] markers (entity_filter single-source dedup), surface
#             retrieved unique docs as implicit citations.
# Changelog: 1.8.3 — AIStudio_618: keywords field on AskRequest — passed to BM25
#             channel as boost terms. Comma-separated list from UI KEYWORDS field.
# Changelog: 1.8.2 — AIStudio_798: entity_filter field on AskRequest + RetrieveRequest.
#            List of source_path substrings with OR semantics — filters retrieval to
#            matching documents only. Works across all corpora without re-ingest.
# Changelog: 1.8.1 — Fix lint: move _read_corpus_meta_defaults() after all imports (E402).
# Changelog: 1.8.0 — AIStudio_778 v2: min_score per-request field on AskRequest + RetrieveRequest.
#            Resolved: per-request override → corpus metadata default_min_score → hardcoded 0.5.
#            Passed to retrieve() as min_score kwarg.
# Changelog: 1.7.9 — AIStudio_738 B+C: per-corpus stored defaults. CreateCorpusRequest accepts default_top_k/temperature/hybrid_alpha; written to corpus_metadata.yaml at creation. get_corpus_info reads and returns those three fields so the UI can apply them on corpus switch.
# Changelog: 1.7.8 — AIStudio_755: add GET /prompt/text and POST /prompt/update. Same file at different pages now gets distinct [N] citations, each pointing to the correct page. LLM context labels each source with its page number.
# Changelog: 1.7.6 — AIStudio_765: serve_source returns text/html for .htm/.html/.xhtml files so browser renders inline instead of downloading.
# Changelog: 1.7.5 — AIStudio_752: strip citation markers [N] from conversation history
#            before injecting into prompt. Citation indices from prior turns refer to
#            different source sets — leaving them in causes the LLM to reuse stale [1]/[2]
#            references against the current query's sources, producing wrong file citations
#            for follow-up questions. Strip [N] from history content only; factual text
#            is preserved. Fixes single-file citation on cross-temporal trend queries.
# Changelog: 1.5.5 — Add avg_seconds_per_file to /corpus/{name}/info response.
#            Add DELETE /corpus/{name}/file/{filename}/chunks endpoint for reingest:
#            wipes Qdrant chunks only (file stays on disk), resets metadata stub.
#            Reingest flow: wipe chunks → POST /ingest to re-embed with current settings.
# Changelog: 1.5.4 — Upload endpoint writes stub to corpus_metadata.yaml (file_type +
#            size_bytes, ingest fields null) so UI shows metadata before ingest.
#            Ingest metadata write now includes file_type label and normalizer fields
#            directly from file_stats (normalizer_entity/year/source/mismatch).
#            Removes normalizer_prefix computed field — UI derives it from entity+year.
# Changelog: 1.5.3 — AIStudio_718: entity alias query expansion before retrieval.
#            _build_entity_alias_map() reads normalizer_entity from corpus_metadata.yaml
#            file_stats and builds token→canonical map. _expand_query_entities() detects
#            entity mentions in query and appends canonical names so BM25 hits right chunks.
#            "BNP Paribas" → "BNP Paribas Groupe BNP Paribas" at retrieval time only;
#            original query preserved for LLM generation. Module-level cache per corpus;
#            invalidated on corpus metadata update. Wired into /ask and /debug/retrieve.
#            pipeline.py v1.8.0. Hits stored in _ingest_status normalizer_hits list; carried
#            into done status. Frontend renders normalizer hits below ingest progress bar.
# Changelog: 1.7.2 — AIStudio_635 + AIStudio_636 (bundled). (635) Inject today's date into system prompt — appends "TODAY'S DATE: YYYY-MM-DD (Weekday)." after the SOURCE COUNT block. Fixes the failure mode where queries like "what happened in the last 5 days" anchor temporally to the most-recent retrieved chunk's date rather than to actual today. Becomes structurally important as M2.D query-understanding progresses (recency filters, "this week" queries all implicitly depend on "now"). (636) Bump conversation_history slice [-6:] → [-20:] = last 10 exchanges (was 3). Aligns implementation with the documented mental model. Negligible memory cost for 7B model (~6KB additional context per query). Comment updated to reflect new depth. NOTE: rag_core.py has a duplicate generate_answer_with_citations() with its own [-6:] slice on line ~252; verified dead code (api.py defines its own at line 118, used by /ask at line 434, rag_core imports only RetrievedDoc + retrieve). Filed AIStudio_637 to remove the duplicate.
# Changelog: 1.7.1 — AIStudio_124 (partial resolution): system prompt now loaded from prompts/system.txt instead of hardcoded inline. New _load_system_prompt() helper with module-level memoization. Inline prompt block at line ~131 replaced with base = _load_system_prompt() + dynamic source-count lines. Corpus search_guidance injection (per-query, post-base) unchanged. Anti-mechanism citation rules + synthesis directives + length-calibration rules added to system.txt simultaneously (addresses retrieval-quality findings AIStudio_628/629/630 at prompt layer).
# Changelog: 1.7.0 — AIStudio_613: ingest progress bar fix. (a) Parse [ingest] file_complete: N/M chunks=C bytes=B lines from pipeline.py v1.5.0+ in async stderr iterator → primary source of files_processed/chunks_written/bytes_processed/d_observed updates (previous tqdm-postfix path only fires at run end). (b) Self-correct d_observed in Qdrant polling path: write live_chunks/bytes_done back to cached state with [1e-5, 1e-2] chunks/byte clamp (rejects pathological intermediate ratios). (c) Reconcile both D_SEED sites (line ~729 and ~1078) to 200 chunks/MB midpoint — between PDF (~40) and markdown (~1000) regimes. Value matters less now that self-correction works.
# Changelog: 1.6.1 — AIStudio_599: remove /debug/stats endpoint and stats:JsonlStats from /corpus/<n>/info response. UI never consumed stats field (verified by grep); chunk_count comes from Qdrant directly. debug_stats.py orphaned (zero callers); deletion pending AIStudio_159.
# Changelog: 1.6.0 — AskRequest.hybrid_alpha field exposed; passed to retrieve() with per-query-override-then-config-default pattern (M2.A hybrid retrieval)
# Changelog: 1.4.6 — AIStudio_707: fix pre-scan files_found count to exclude trash/ subdirectory (was counting directory as a file).
# Changelog: 1.4.5 — AIStudio_517: fix allowed_extensions to match SUPPORTED_EXTS in loaders.py (added .pptx/.xlsx/.htm/.html)
# Changelog: 1.4.4 — AIStudio_517: reject unsupported file extensions in upload endpoint (.pdf/.txt/.md/.docx only)
# Changelog: 1.4.3 — less defensive system prompt; direct confident answer rules (AIStudio_483); strip trailing References block
# Changelog: 1.4.1 — renumber citations by first appearance in answer text, two-pass placeholder approach (AIStudio_480)
# Changelog: 1.4.0 — per-file stats in corpus_metadata.yaml (files:/deleted_files: schema); avg_seconds_per_file
# Changelog: 1.3.0 — corpus_meta → corpus_metadata rename; schema_version/last_updated/short_description fields; expand CreateCorpusRequest
# Changelog: 1.1.0 — live Qdrant chunk count in ingest-status; MD5 file endpoint; offline-first (no CDN deps)
from __future__ import annotations

import asyncio
import json
import os
import re
import shutil
import time
from contextlib import asynccontextmanager
from datetime import datetime as _dt
from pathlib import Path
from typing import Annotated, Any

import yaml as _yaml
from fastapi import Body, FastAPI, File, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel

from local_llm_bot.app.config import CONFIG
from local_llm_bot.app.ingest.index_jsonl import read_jsonl
from local_llm_bot.app.ingest.loaders import SUPPORTED_EXTS
from local_llm_bot.app.ollama_client import ollama_generate
from local_llm_bot.app.rag_core import (
    RetrievedDoc,
    _detect_entities,
    _resolve_entity_filter_tokens,
    retrieve,
)
from local_llm_bot.app.utils.corpus_paths import corpus_exists, corpus_paths, list_corpora
from local_llm_bot.app.utils.repo_root import find_repo_root


def _read_corpus_meta_defaults(corpus_name: str) -> dict:
    """
    Lightweight helper — reads only default_* fields from corpus_metadata.yaml.
    Used by /ask and /debug/retrieve to resolve per-corpus defaults without
    invoking the full get_corpus_info() route handler.
    Returns dict with default_top_k, default_temperature, default_hybrid_alpha,
    default_min_score — any absent field returns None.
    """
    try:
        repo_root = _get_repo_root()
        paths = corpus_paths(repo_root=repo_root, corpus=corpus_name)
        meta_path = paths["base"] / f"{corpus_name}_corpus_metadata.yaml"
        if meta_path.exists():
            with open(meta_path) as f:
                meta = _yaml.safe_load(f) or {}
            return {
                "default_top_k":        meta.get("default_top_k"),
                "default_temperature":  meta.get("default_temperature"),
                "default_hybrid_alpha": meta.get("default_hybrid_alpha"),
                "default_min_score":    meta.get("default_min_score"),
            }
    except Exception:
        pass
    return {"default_top_k": None, "default_temperature": None, "default_hybrid_alpha": None, "default_min_score": None}

# ============================================================================
# INLINE CITATION SUPPORT (embedded in API for simplicity)
# ============================================================================


def extract_page_number(source_path: str, chunk_id: str = "") -> int | None:
    """Extract page number from source path or chunk_id"""
    # Try from source path: "document.pdf#page=5"
    page_match = re.search(r"#page=(\d+)", source_path)
    if page_match:
        return int(page_match.group(1))

    # Try from filename: "document_p12.pdf"
    page_match = re.search(r"[_\-]p(\d+)", source_path, re.IGNORECASE)
    if page_match:
        return int(page_match.group(1))

    # Try from chunk_id: "chunk-page-3"
    if chunk_id:
        page_match = re.search(r"page[_\-]?(\d+)", chunk_id, re.IGNORECASE)
        if page_match:
            return int(page_match.group(1))

    return None


def _load_corpus_search_guidance(corpus_name: str) -> str:
    """
    Load search_guidance from {corpus_name}_corpus_metadata.yaml if it exists.
    Returns empty string silently if file missing or field absent.
    """
    try:
        repo_root = _get_repo_root()
        meta_path = (
            repo_root / "data" / "corpora" / corpus_name / f"{corpus_name}_corpus_metadata.yaml"
        )
        if meta_path.exists():
            with open(meta_path) as f:
                meta = _yaml.safe_load(f) or {}
            guidance = meta.get("search_guidance", "").strip()
            return guidance
    except Exception:
        pass
    return ""


def _build_entity_alias_map(corpus_name: str) -> dict[str, str]:
    """
    AIStudio_718 — Build a token→canonical_entity map from corpus_metadata.yaml file_stats.

    Each file entry with a normalizer_entity field contributes its canonical name.
    The map covers common abbreviation patterns:
      - Each individual word in the entity name (≥4 chars, not stopwords)
      - The full entity name lowercased
      - Common short forms (e.g. "bnp" from "Groupe BNP Paribas")

    Returns {lowercase_token: canonical_entity_name}
    Used by _expand_query_entities() to rewrite queries before retrieval.
    """
    _STOPWORDS = {"the", "and", "for", "bank", "group", "groep", "groupe", "holding",
                  "corp", "inc", "ltd", "plc", "nv", "sa", "spa", "s.a.", "n.v.",
                  "s.p.a.", "aktiengesellschaft", "konzern", "koncernen"}
    alias_map: dict[str, str] = {}
    try:
        repo_root = _get_repo_root()
        meta_path = (
            repo_root / "data" / "corpora" / corpus_name / f"{corpus_name}_corpus_metadata.yaml"
        )
        if not meta_path.exists():
            return alias_map
        with open(meta_path) as f:
            meta = _yaml.safe_load(f) or {}
        files = meta.get("files", {}) or {}
        seen_entities: set[str] = set()
        for _fname, fdata in files.items():
            entity = (fdata or {}).get("normalizer_entity", "")
            if not entity or entity in seen_entities:
                continue
            seen_entities.add(entity)
            # Full entity name → itself
            alias_map[entity.lower()] = entity
            # Each significant token
            for token in re.split(r"[\s\.,·\-]+", entity):
                token_clean = re.sub(r"[^a-z0-9]", "", token.lower())
                # Only map if significant and unambiguous (don't let short tokens clobber each other)
                if len(token_clean) >= 3 and token_clean not in _STOPWORDS and token_clean not in alias_map:
                    alias_map[token_clean] = entity
    except Exception:
        pass
    return alias_map


# Module-level cache: {corpus_name: alias_map}
_ENTITY_ALIAS_CACHE: dict[str, dict[str, str]] = {}


def _detect_query_entities(query: str, corpus_name: str) -> list[str]:
    """
    AIStudio_876 — Detect canonical entities mentioned in a query.

    Now delegates to rag_core._detect_entities — THE single detection function
    (GLEIF-KB-sourced, accent+case-insensitive, word-boundary matched). Expansion
    and the entity filter therefore use identical detection: there is no longer a
    separate api.py alias map built from normalizer_entity. Returns canonical names.
    """
    try:
        return [e["canonical"] for e in _detect_entities(query, corpus_name)]
    except Exception:
        return []


def _expand_query_entities(query: str, corpus_name: str, repeat: int = 1) -> str:
    """
    AIStudio_718 / AIStudio_875 — Substitute entity mentions in a query with the
    canonical corpus name, optionally repeated for BM25 term-weighting.

    `repeat` (the --query-expansion N knob):
      0 → no expansion, query returned unchanged.
      1 → each detected canonical name is appended once (substitution-equivalent;
          BM25 is bag-of-tokens so position is immaterial, and appending avoids
          mangling the question on a partial match — see HOWTO_OPS / 2026-05-30).
      N>1 → the canonical name is appended N times, increasing its BM25 weight.

    Rewrite affects ONLY the retrieval query (vector + BM25), never the query sent
    to the LLM (the user sees their own words). Silent fallback on any error.
    Example (repeat=1): "CET1 ratio for BNP" → "CET1 ratio for BNP Groupe BNP Paribas"
    """
    try:
        if repeat <= 0:
            return query
        detected = _detect_query_entities(query, corpus_name)
        query_lower = query.lower()
        additions: list[str] = []
        for canonical in detected:
            # Skip if the canonical full name is already literally in the query
            if canonical.lower() in query_lower:
                continue
            additions.extend([canonical] * repeat)
        if additions:
            return query + " " + " ".join(additions)
    except Exception:
        pass
    return query


def _auto_entity_filter(query: str, corpus_name: str) -> list[str] | None:
    """
    AIStudio_875 / AIStudio_876 — Build a retrieval entity_filter from entities
    detected in the query (the --entity-filter auto mode). This is the wiring that
    was missing: recognized entities feed not just the query string but the Qdrant
    source_path filter, so off-target firms (BlackRock, BNY Mellon, …) are EXCLUDED,
    not merely out-ranked.

    AIStudio_876: the canonical→source_path-token mapping is now sourced from the
    declared entity knowledge base (rag_core._resolve_entity_filter_tokens, keyed off
    each entity's scope_name), unifying expansion and filter on one KB rather than an
    ad-hoc filename split. Returns a list of source_path tokens, or None if nothing
    detected / no KB for this corpus.
    """
    try:
        tokens = _resolve_entity_filter_tokens(query, corpus_name)
        return tokens or None
    except Exception:
        return None


# AIStudio_124 (partial): system prompt base loaded from prompts/system.txt
# Memoized at module level — file is read once per process. Restart api.py
# to pick up edits. Fallback to minimal inline string if file missing so
# the system never breaks on a fresh install before prompts/ is provisioned.
_SYSTEM_PROMPT_BASE: str | None = None


def _load_system_prompt() -> str:
    """
    Load base system prompt from prompts/system.txt at repo root.
    Memoized after first call. Falls back to a minimal default if the file
    is absent, ensuring the system never breaks on a fresh install.
    """
    global _SYSTEM_PROMPT_BASE
    if _SYSTEM_PROMPT_BASE is None:
        try:
            repo_root = _get_repo_root()
            prompts_path = repo_root / "prompts" / "system.txt"
            if prompts_path.exists():
                _SYSTEM_PROMPT_BASE = prompts_path.read_text(encoding="utf-8").rstrip()
            else:
                _SYSTEM_PROMPT_BASE = (
                    "You are a research assistant. Answer using the provided sources. "
                    "Cite every factual claim with [N] where N is the source number."
                )
        except Exception:
            _SYSTEM_PROMPT_BASE = (
                "You are a research assistant. Answer using the provided sources. "
                "Cite every factual claim with [N] where N is the source number."
            )
    return _SYSTEM_PROMPT_BASE


def generate_answer_with_citations(
    query: str,
    docs: list[RetrievedDoc],
    conversation_history: list[dict[str, str]] | None = None,
    corpus: str | None = None,
    model: str | None = None,
    temperature: float | None = None,
) -> dict[str, Any]:
    """Generate answer with citation support"""

    if not docs:
        return {
            "answer": "I don't have any relevant documents to answer this question.",
            "citations": [],
            "has_citations": False,
        }

    # Build context with numbered sources
    # AIStudio_768 — Deduplicate by (source, page) so chunks from the same file but
    # different pages get distinct citation numbers. Same file + same page → merged.
    # This ensures each [N] in the answer maps to a specific page, not just a file.
    seen_source_pages: dict[tuple[str, int | None], int] = {}
    source_chunks: dict[int, list[str]] = {}
    doc_to_index: dict[int, int] = {}  # original doc position -> source-page index

    for i, doc in enumerate(docs):
        page = extract_page_number(doc.source, doc.id)
        key = (doc.source, page)
        if key not in seen_source_pages:
            idx = len(seen_source_pages) + 1
            seen_source_pages[key] = idx
            source_chunks[idx] = []
        idx = seen_source_pages[key]
        # AIStudio_720 — [Document: entity FY year] prefix is intentionally preserved in
        # chunk content sent to LLM. It is the entity attribution signal in a multi-firm
        # corpus — without it the model cannot reliably attribute CET1 ratios, financial
        # metrics, or any entity-specific claim to the correct firm. Stripping it here
        # caused hallucinated entity attribution (T2.46). The prefix is stripped from the
        # generated *answer* text only (post-processing below), never from the input context.
        source_chunks[idx].append(doc.content)
        doc_to_index[i] = idx

    context_parts = []
    for (src, page), idx in seen_source_pages.items():
        combined = "\n\n".join(source_chunks[idx])
        page_label = f" (p. {page})" if page is not None else ""
        # AIS_26 — label sources by BASENAME, not the absolute path. The LLM echoes whatever
        # source label it's shown; with the full path it leaked raw filesystem paths (incl.
        # the foreign ingest-time root /Users/<other>/...) into answer prose. The basename is
        # sufficient source context and renders cleanly if echoed. Citation metadata still
        # carries the full doc.source for Source Dive (unchanged below).
        src_name = Path(str(src).split("#")[0]).name
        context_parts.append(f"[{idx}] {src_name}{page_label}\n{combined}")

    context = "\n\n".join(context_parts)

    # Build unique_docs list keyed by (source, page) for citation metadata lookup
    unique_docs = []
    seen_keys: set[tuple[str, int | None]] = set()
    for doc in docs:
        page = extract_page_number(doc.source, doc.id)
        key = (doc.source, page)
        if key not in seen_keys:
            seen_keys.add(key)
            unique_docs.append(doc)
    docs = unique_docs

    # System prompt: base loaded from prompts/system.txt (AIStudio_124 partial resolution v1.7.1).
    # Dynamic source-count constraint appended per-query since it depends on retrieval result.
    # Today's date injected per-query (AIStudio_635 v1.7.2) so temporal queries anchor to actual
    # today rather than the most-recent retrieved chunk's date.
    # Corpus search_guidance injected below as a final per-corpus addendum.
    num_sources = len(docs)
    base = _load_system_prompt()
    system = (
        base
        + "\n\n"
        + f"SOURCE COUNT — there are exactly {num_sources} sources, numbered [1] through [{num_sources}]. "
        + f"NEVER use numbers outside the range [1] to [{num_sources}] as citations."
        + f"\n\nTODAY'S DATE: {_dt.now().strftime('%Y-%m-%d (%A)')}."
    )

    # Inject corpus search guidance if available ({corpus}_corpus_metadata.yaml → search_guidance field)
    if corpus:
        guidance = _load_corpus_search_guidance(corpus)
        if guidance:
            system += (
                "\n\nCORPUS SEARCH GUIDANCE — follow these routing rules when selecting sources:\n"
                + guidance
            )

    # Build prompt with conversation history
    if conversation_history:
        # Strip citation markers [N] from history — indices from prior turns refer to
        # different source sets and bleed into current citations if left in (AIStudio_752).
        def _strip_citations(text: str) -> str:
            return re.sub(r"\[\d+(?:\s*,\s*\d+)*\]", "", text).strip()

        history_text = "\n".join(
            [
                f"{msg['role'].upper()}: {_strip_citations(msg['content'])}"
                for msg in conversation_history[-20:]  # Last 10 exchanges (user+assistant = 20 msgs) — AIStudio_636 v1.7.2
            ]
        )
        prompt = f"Conversation History:\n{history_text}\n\nCurrent Question:\n{query}\n\nAvailable Sources:\n{context}\n\nAnswer:"
    else:
        prompt = f"Question:\n{query}\n\nAvailable Sources:\n{context}\n\nAnswer:"

    # Generate answer
    answer = ollama_generate(model=model or CONFIG.rag.default_model, prompt=prompt, system=system, temperature=temperature)

    # Strip any trailing References/Sources block the LLM appended despite instructions.
    # Handles both newline-prefixed and inline variants (Mistral:7b appends inline).
    answer = re.sub(
        r"\n*(?:References|Sources|Citations)\s*:?\s*(?:\n.*)*$", "", answer, flags=re.IGNORECASE
    ).rstrip()

    # AIStudio_720 belt-and-suspenders: strip any [Document: ...] prefix that leaked
    # into the answer from conversation history or other path
    answer = re.sub(r'\[Document:[^\]]+\]\s*', '', answer).strip()

    # Extract citations from answer
    citations = []
    cited_indices = set()

    # Normalize [Source N] -> [N] before extracting
    answer = re.sub(r"\[Source\s+(\d+)\]", r"[\1]", answer, flags=re.IGNORECASE)
    # AIS_25 — Normalize page-bearing markers the LLM emits despite instructions, e.g.
    # "[3, p. 10]" / "[4, page 45]" / "[2, pp. 5-7]" → "[3]" / "[4]" / "[2]". Small models
    # imitate the page-labeled context ("[N] <src> (p. X)") by folding the page INTO the
    # marker; the pure-numeric extractor below ([N]/[N,M]) then fails to match them, so they
    # were silently dropped — leaving dangling unresolved markers in the text and missing rows
    # in REFERENCES. The page is recovered authoritatively from the (source, page) dedup
    # (AIStudio_768), so the embedded page is redundant (and model page-claims can be wrong);
    # stripping it is safe and correct. Multi-cite [2,3] is NOT matched (no p./page token).
    answer = re.sub(
        r"\[(\d+)\s*,\s*(?:p{1,2}\.?|pages?|pg\.?)\s*\d+(?:\s*[-–]\s*\d+)?\s*\]",
        r"[\1]", answer, flags=re.IGNORECASE,
    )
    # Find all citation patterns: [1], [2,3], [1][2], etc.
    citation_patterns = re.findall(r"\[(\d+(?:\s*,\s*\d+)*)\]", answer)

    for pattern in citation_patterns:
        for idx_str in re.split(r",\s*", pattern):
            idx = int(idx_str.strip())
            if idx > 0 and idx <= len(docs) and idx not in cited_indices:
                doc = docs[idx - 1]
                page = extract_page_number(doc.source, doc.id)

                citations.append(
                    {
                        "index": idx,
                        "source": doc.source,
                        "page": page,
                        "chunk_id": doc.id,
                        "score": float(doc.score),
                    }
                )
                cited_indices.add(idx)

    # Sort citations by index
    citations.sort(key=lambda c: c["index"])

    # Renumber citations by first appearance in answer text — AIStudio_480 / AIS_31
    # Ensures [1] appears before [2] regardless of retrieval order, AND keeps multi-cites
    # in sync. AIS_31: the old pass scanned/rewrote only single brackets (\[\d+\]), so a
    # multi-cite like [1,2] was neither scanned for appearance nor renumbered — an index that
    # appeared ONLY inside a multi-cite got pushed to the end and orphaned (a REFERENCES row
    # with no visible marker), and the stale [1,2] then pointed at the wrong sources. Fix:
    # parse every bracket's indices one-by-one (single AND multi) and remap via a replacement
    # callback — no clever placeholder-swap, just explicit per-token logic.
    if citations:
        cited_set = {c["index"] for c in citations}
        _grp = re.compile(r"\[(\d+(?:\s*,\s*\d+)*)\]")

        # Pass 0 — walk every citation group left-to-right; first time a cited index is
        # seen (in a single OR multi bracket), assign it the next appearance number.
        appearance_order: dict[int, int] = {}
        for m in _grp.finditer(answer):
            for tok in m.group(1).split(","):
                old = int(tok.strip())
                if old in cited_set and old not in appearance_order:
                    appearance_order[old] = len(appearance_order) + 1
        # Any cited index never found in text (shouldn't happen post-fix) → append at end.
        for c in citations:
            if c["index"] not in appearance_order:
                appearance_order[c["index"]] = len(appearance_order) + 1

        # Pass 1 — rewrite every bracket (single or multi) by remapping each index in place.
        def _remap(m: re.Match[str]) -> str:
            # AIS_31 (2nd pass, 1.10.8): keep ONLY tokens that became real citations
            # (present in appearance_order). Drop out-of-range / uncited indices the model
            # invents — e.g. top_k=5 but it writes "[5,6]"; index 6 has no retrieved source,
            # so the extractor (idx <= len(docs) guard) never added it as a citation. The old
            # `.get(t, t)` default KEPT such a token verbatim → a dangling marker with no
            # REFERENCES row (markers/references desync). Now we drop it; if a bracket loses
            # every token, the whole bracket is removed.
            mapped = [str(appearance_order[int(t.strip())])
                      for t in m.group(1).split(",")
                      if int(t.strip()) in appearance_order]
            return "[" + ",".join(mapped) + "]" if mapped else ""
        answer = _grp.sub(_remap, answer)
        # Tidy any space left where a fully-invalid bracket was removed ("text [6]." → "text .").
        answer = re.sub(r"[ \t]+([.,;:])", r"\1", answer)

        # Update citation dicts and re-sort by new index.
        for c in citations:
            c["index"] = appearance_order[c["index"]]
        citations.sort(key=lambda c: c["index"])

    return {"answer": answer, "citations": citations, "has_citations": len(citations) > 0}


@asynccontextmanager
async def lifespan(app: FastAPI):
    # AIS_27 — lifespan replaces the deprecated @app.on_event handlers.
    # Startup: nothing to set up. Shutdown trace runs after `yield`.
    yield
    # AIS_17 — backend-kill observability: leave a trace in the log when the server stops.
    # uvicorn fires this on a graceful SIGTERM (e.g. a long ingest interrupted by a stop/restart),
    # so a vanished backend is no longer silent. A hard SIGKILL (kill -9) can't be caught and won't
    # fire this — the ingest-side lsof preflight (ais_ingest_*.sh) covers a replaced/missing listener.
    import sys
    print("[backend] shutdown — server stopping (SIGTERM / graceful stop)", file=sys.stderr, flush=True)


app = FastAPI(title="AIStudio Local LLM Bot", lifespan=lifespan)

# In-memory ingest status keyed by corpus name
_ingest_status: dict[str, dict] = {}

# In-memory ingest process tracking — used by cancel endpoint
_ingest_proc: dict[str, Any] = {}  # corpus_name -> asyncio.subprocess.Process

# Add CORS middleware to allow frontend connections
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify your frontend URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class AskRequest(BaseModel):
    query: str
    corpus: str = "default"
    top_k: int | None = None
    temperature: float | None = None
    top_p: float | None = None
    conversation_history: list[dict[str, str]] | None = None  # NEW: For follow-up questions
    hybrid_alpha: float | None = None  # M2.A: per-query override; None falls back to CONFIG.rag.hybrid_alpha
    min_score: float | None = None    # AIStudio_778: per-query min score threshold override
    entity_filter: list[str] | None = None  # AIStudio_798: OR filter on source_path substrings
    allowed_source_paths: list[str] | None = None  # AIStudio_882: scope boundary, ANDed with entity_filter
    keywords: list[str] | None = None         # AIStudio_618: BM25 boost terms from UI KEYWORDS field
    model: str | None = None                   # Per-request model override; falls back to CONFIG.rag.default_model
    query_expansion: int = 1                    # AIStudio_875: entity-name expansion repeat count (0=off, 1=once, N=weighted)
    entity_filter_mode: str = "auto"            # AIStudio_875: none | yaml | auto. 'auto' self-populates entity_filter from detected entities when none supplied.


class CitationResponse(BaseModel):
    index: int
    source: str
    page: int | None = None
    chunk_id: str | None = None
    score: float = 0.0


class AskResponse(BaseModel):
    answer: str
    citations: list[CitationResponse] | None = None  # NEW: Citation metadata
    has_citations: bool = False  # NEW: Flag indicating if citations are present
    retrieval_query: str | None = None   # AIStudio_841: expanded query actually sent to retrieve()
    model_used: str | None = None        # AIStudio_841: model actually used for generation


class RetrieveRequest(BaseModel):
    query: str
    corpus: str = "default"
    top_k: int = 5
    hybrid_alpha: float | None = None  # M2.A: per-call hybrid weight override
    min_score: float | None = None    # AIStudio_778: per-call min score threshold override
    entity_filter: list[str] | None = None  # AIStudio_798: OR filter on source_path substrings
    allowed_source_paths: list[str] | None = None  # AIStudio_882: scope boundary, ANDed with entity_filter
    keywords: list[str] | None = None  # AIStudio_841: BM25 boost terms for debug retrieval


class CorpusInfo(BaseModel):
    name: str
    document_count: int | None = None
    size_bytes: int | None = None


class ModelInfo(BaseModel):
    id: str
    name: str
    provider: str
    available: bool = True


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


# Track which models are currently loaded in Ollama memory
_warm_models: set[str] = set()


@app.post("/prewarm")
async def prewarm(model_id: str | None = None) -> dict[str, str]:
    """
    Fire a throwaway request to load the model into unified memory.
    Subsequent queries skip the cold-start penalty (~20-50s → ~7s).
    If model_id is provided, warms that model; otherwise warms the default.
    """
    model = model_id or CONFIG.rag.default_model
    if model in _warm_models:
        return {"status": "already_warm", "model": model}
    try:
        ollama_generate(model=model, prompt="hi", system="")
        _warm_models.add(model)
        return {"status": "warm", "model": model}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Prewarm failed: {str(e)}") from e


def _require_corpus(corpus: str) -> None:
    if not corpus_exists(find_repo_root(Path(__file__)), corpus):
        raise HTTPException(
            status_code=404,
            detail={
                "error": f"Unknown corpus '{corpus}'",
                "available": list_corpora(find_repo_root(Path(__file__))),
            },
        )


def _get_repo_root() -> Path:
    """Get repository root directory"""
    return find_repo_root(Path(__file__))


def _get_corpus_document_count(corpus_name: str) -> int:
    """Count documents in a corpus by reading the index.jsonl file"""
    try:
        repo_root = _get_repo_root()
        paths = corpus_paths(repo_root=repo_root, corpus=corpus_name)
        index_file = paths["index"]

        if not index_file.exists():
            return 0

        rows = read_jsonl(index_file)
        # Count unique document IDs
        doc_ids = set()
        for row in rows:
            doc_id = row.get("doc_id", "")
            if doc_id:
                doc_ids.add(doc_id)

        return len(doc_ids)
    except Exception as e:
        print(f"Error counting documents: {e}")
        return 0


def _get_corpus_size(corpus_name: str) -> int:
    """Get total size of corpus directory in bytes"""
    try:
        repo_root = _get_repo_root()
        paths = corpus_paths(repo_root=repo_root, corpus=corpus_name)
        corpus_dir = paths["base"]

        if not corpus_dir.exists():
            return 0

        total_size = 0
        for dirpath, _dirnames, filenames in os.walk(corpus_dir):
            for f in filenames:
                fp = os.path.join(dirpath, f)
                if os.path.exists(fp):
                    total_size += os.path.getsize(fp)

        return total_size
    except Exception as e:
        print(f"Error calculating corpus size: {e}")
        return 0


@app.post("/ask", response_model=AskResponse)
async def ask(req: AskRequest) -> AskResponse:
    if not req.query.strip():
        raise HTTPException(status_code=400, detail="query must not be empty")
    _require_corpus(req.corpus)

    # Use provided top_k or default from config
    top_k = req.top_k if req.top_k is not None else CONFIG.rag.top_k

    # Use provided hybrid_alpha or default from config (M2.A hybrid retrieval).
    # If both are None, retrieve() runs in vector-only mode (preserves pre-M2.A behavior).
    hybrid_alpha = req.hybrid_alpha if req.hybrid_alpha is not None else CONFIG.rag.hybrid_alpha

    # AIStudio_718 / AIStudio_875 — expand entity mentions in query to canonical corpus
    # names before retrieval. repeat count from --query-expansion (req.query_expansion).
    # Original query preserved for LLM generation (user sees their words).
    retrieval_query = _expand_query_entities(req.query, req.corpus, repeat=req.query_expansion)

    # AIStudio_875 — resolve the effective entity_filter from entity_filter_mode:
    #   none → no filter; yaml → caller-supplied req.entity_filter as-is;
    #   auto → if caller supplied none, self-populate from entities detected in the query
    #          (maps recognized canonical entity → source_path token). This is the wiring
    #          that turns recognition into an actual retrieval-time constraint, so off-target
    #          firms are EXCLUDED rather than merely out-ranked (the F8 finding, 2026-05-30).
    _mode = (req.entity_filter_mode or "auto").lower()
    if _mode == "none":
        _effective_entity_filter = None
    elif _mode == "yaml":
        _effective_entity_filter = req.entity_filter or None
    else:  # auto
        _effective_entity_filter = req.entity_filter or _auto_entity_filter(req.query, req.corpus)

    # Retrieve relevant documents
    # Resolve min_score: per-request → corpus metadata default → hardcoded fallback
    _corpus_meta = _read_corpus_meta_defaults(req.corpus)
    _corpus_min_score = _corpus_meta.get("default_min_score")
    _MIN_SCORE_FALLBACK = 0.5
    min_score = req.min_score if req.min_score is not None else (_corpus_min_score if _corpus_min_score is not None else _MIN_SCORE_FALLBACK)
    docs = retrieve(query=retrieval_query, top_k=top_k, corpus=req.corpus, hybrid_alpha=hybrid_alpha, min_score=min_score, entity_filter=_effective_entity_filter, allowed_source_paths=req.allowed_source_paths or None, keywords=req.keywords or None)

    # Generate answer with citations
    result = generate_answer_with_citations(
        query=req.query,
        docs=docs,
        conversation_history=req.conversation_history,
        corpus=req.corpus,
        model=req.model or None,
        temperature=req.temperature if req.temperature is not None else None,
    )

    # Convert to response format
    citation_responses = (
        [CitationResponse(**c) for c in result["citations"]] if result["citations"] else None
    )

    return AskResponse(
        answer=result["answer"],
        citations=citation_responses,
        has_citations=result["has_citations"],
        retrieval_query=retrieval_query,  # always return — shows query after entity expansion
        model_used=req.model or CONFIG.rag.default_model,
    )


@app.post("/debug/retrieve")
async def debug_retrieve(req: RetrieveRequest) -> dict[str, Any]:
    _require_corpus(req.corpus)
    hybrid_alpha = req.hybrid_alpha if req.hybrid_alpha is not None else CONFIG.rag.hybrid_alpha
    retrieval_query = _expand_query_entities(req.query, req.corpus)
    _corpus_meta_dbg = _read_corpus_meta_defaults(req.corpus)
    _corpus_min_score_dbg = _corpus_meta_dbg.get("default_min_score")
    min_score_dbg = req.min_score if req.min_score is not None else (_corpus_min_score_dbg if _corpus_min_score_dbg is not None else 0.5)
    docs = retrieve(
        query=retrieval_query, top_k=req.top_k, corpus=req.corpus, hybrid_alpha=hybrid_alpha,
        min_score=min_score_dbg, entity_filter=req.entity_filter or None,
        allowed_source_paths=req.allowed_source_paths or None,
        keywords=req.keywords or None,
    )
    return {
        "count": len(docs),
        "retrieval_query": retrieval_query,
        "retrieval_query_expanded": retrieval_query != req.query,
        "min_score_used": min_score_dbg,
        "docs": [
            {
                "id": d.id,
                "score": d.score,
                "source": d.source,
                "content_preview": (d.content[:280] + "...") if len(d.content) > 280 else d.content,
            }
            for d in docs
        ],
        "config": {
            "use_chroma": CONFIG.rag.use_chroma,
            "hybrid_enabled": getattr(CONFIG.rag, "hybrid_enabled", False),
            "decompose_multi_entity": getattr(CONFIG.rag, "decompose_multi_entity", False),
        },
    }


# CORPUS MANAGEMENT ENDPOINTS


@app.get("/corpora")
async def get_corpora() -> list[CorpusInfo]:
    """
    Get list of available corpora with metadata.
    """
    corpus_names = list_corpora(find_repo_root(Path(__file__)))

    corpora_info = []
    for name in corpus_names:
        doc_count = _get_corpus_document_count(name)
        size_bytes = _get_corpus_size(name)

        corpora_info.append(CorpusInfo(name=name, document_count=doc_count, size_bytes=size_bytes))

    return corpora_info


@app.get("/corpus/{corpus_name}/info")
async def get_corpus_info(corpus_name: str) -> dict[str, Any]:
    """
    Get detailed information about a specific corpus.
    """
    _require_corpus(corpus_name)

    repo_root = _get_repo_root()
    paths = corpus_paths(repo_root=repo_root, corpus=corpus_name)

    # Get basic stats — chunk count from Qdrant (source of truth post-Qdrant migration);
    # JSONL-derived stats removed per AIStudio_599 (debug_stats.py orphaned, removal pending AIStudio_159)
    size_bytes = _get_corpus_size(corpus_name)

    # List files in corpus — source of truth for doc count (live filesystem, not stale index)
    uploads_dir = paths["uploads"]
    files: list[str] = []
    file_details: list[dict] = []
    if uploads_dir.exists():
        for f in sorted(uploads_dir.iterdir()):
            if f.is_file() and not f.name.startswith("."):
                files.append(f.name)
                file_details.append({"name": f.name, "size_bytes": f.stat().st_size})
    doc_count = len(files)

    # Get real chunk count from Qdrant (live — not from stale manifest)
    qdrant_chunk_count = 0
    try:
        from qdrant_client import QdrantClient

        qc = QdrantClient(host="localhost", port=6333)
        col_info = qc.get_collection(f"aistudio_{corpus_name}")
        qdrant_chunk_count = col_info.points_count or 0
    except Exception:
        qdrant_chunk_count = 0  # Qdrant unavailable; no JSONL fallback (debug_stats.py removed)

    # Load all metadata from corpus_metadata.yaml if available
    last_ingested_at = None
    ingest_duration_seconds = None
    last_ingest_chunks = None
    last_ingest_files = None
    short_description = ""
    description = ""
    content_summary = ""
    search_guidance = ""
    schema_version = "1.0"
    last_updated = None
    files_meta: dict = {}
    avg_seconds_per_file = None
    default_top_k = None
    default_temperature = None
    default_hybrid_alpha = None
    default_min_score = None
    try:
        meta_path = paths["base"] / f"{corpus_name}_corpus_metadata.yaml"
        if meta_path.exists():
            with open(meta_path) as f:
                meta = _yaml.safe_load(f) or {}
            last_ingested_at = meta.get("last_ingested_at")
            ingest_duration_seconds = meta.get("ingest_duration_seconds")
            last_ingest_chunks = meta.get("last_ingest_chunks")
            last_ingest_files = meta.get("last_ingest_files")
            short_description = meta.get("short_description", "")
            description = meta.get("description", "")
            content_summary = meta.get("content_summary", "")
            search_guidance = meta.get("search_guidance", "")
            schema_version = meta.get("schema_version", "1.0")
            last_updated = meta.get("last_updated")
            files_meta = meta.get("files") or {}
            avg_seconds_per_file = meta.get("avg_seconds_per_file")
            default_top_k = meta.get("default_top_k")
            default_temperature = meta.get("default_temperature")
            default_hybrid_alpha = meta.get("default_hybrid_alpha")
            default_min_score = meta.get("default_min_score")
    except Exception:
        pass

    return {
        "name": corpus_name,
        "status": "available",
        "document_count": doc_count,
        "chunk_count": qdrant_chunk_count,
        "size_bytes": size_bytes,
        "files": files,
        "file_details": file_details,
        "file_count": len(files),
        "last_ingested_at": last_ingested_at,
        "ingest_duration_seconds": ingest_duration_seconds,
        "last_ingest_chunks": last_ingest_chunks,
        "last_ingest_files": last_ingest_files,
        "short_description": short_description,
        "description": description,
        "content_summary": content_summary,
        "search_guidance": search_guidance,
        "schema_version": schema_version,
        "last_updated": last_updated,
        "avg_seconds_per_file": avg_seconds_per_file,
        "files_meta": files_meta,
        "default_top_k": default_top_k,
        "default_temperature": default_temperature,
        "default_hybrid_alpha": default_hybrid_alpha,
        "default_min_score": default_min_score,
        "paths": {
            "base": str(paths["base"]),
            "uploads": str(paths["uploads"]),
            "index": str(paths["index"]),
        },
    }


@app.patch("/corpus/{corpus_name}/metadata")
async def update_corpus_metadata(corpus_name: str, request: Request) -> dict[str, Any]:
    """
    Update editable metadata fields for a corpus.
    Accepts any subset of: short_description, description, content_summary, search_guidance
    Preserves runtime fields (last_ingested_at, etc.) and updates last_updated.
    """
    _require_corpus(corpus_name)
    body = await request.json()

    repo_root = _get_repo_root()
    paths = corpus_paths(repo_root=repo_root, corpus=corpus_name)
    meta_path = paths["base"] / f"{corpus_name}_corpus_metadata.yaml"

    # Load existing metadata or create scaffold
    if meta_path.exists():
        with open(meta_path) as f:
            meta = _yaml.safe_load(f) or {}
    else:
        meta = {"schema_version": "1.0", "corpus_name": corpus_name}

    # Update only fields provided in request — text metadata + per-corpus query defaults
    editable = [
        "short_description", "description", "content_summary", "search_guidance",
        "default_top_k", "default_temperature", "default_hybrid_alpha", "default_min_score",
    ]
    for field in editable:
        if field in body:
            meta[field] = body[field]

    from datetime import date as _date

    meta["last_updated"] = _date.today().isoformat()

    with open(meta_path, "w") as f:
        f.write(f"# {corpus_name}_corpus_metadata.yaml\n")
        f.write("# Corpus metadata — loaded by api.py at query time\n\n")
        _yaml.dump(meta, f, allow_unicode=True, default_flow_style=False, sort_keys=False)

    # Invalidate entity alias cache so next query rebuilds from updated metadata
    _ENTITY_ALIAS_CACHE.pop(corpus_name, None)

    return {
        "status": "updated",
        "corpus": corpus_name,
        "updated_fields": [k for k in editable if k in body],
    }


async def _run_ingest_background(corpus_name: str, uploads_dir, only_files: set[str] | None = None) -> None:
    """Run ingest as a background task after upload.

    Streams stderr line-by-line to parse tqdm progress output in real time.
    tqdm emits lines like:
      Process: 100%|...| 143/143 [03:46<00:00, 1.59s/file, chunks=105964, failed=0, processed=143, skipped=0]
    We parse chunks=N, processed=N, and elapsed time so the UI can show live progress.

    only_files: when set, passed to the ingest CLI as --files so ONLY those files
    are processed (and always re-embedded); all others under uploads/ are untouched.
    """
    import sys

    cmd = [
        sys.executable,
        "-m",
        "local_llm_bot.app.ingest",
        "--corpus",
        corpus_name,
        "--root",
        str(uploads_dir),
    ]
    if only_files:
        cmd += ["--files", ",".join(sorted(only_files))]
    env = {**os.environ, "PYTHONPATH": "src", "PYTHONUNBUFFERED": "1"}
    start_time = time.time()
    # Preserve pre-scan data (file_sizes, total_bytes, files_total) from trigger_ingest.
    # Only reset runtime fields — do NOT wipe the pre-scan that was just computed.
    existing = _ingest_status.get(corpus_name, {})
    _ingest_status[corpus_name] = {
        "status": "running",
        "chunks_written": 0,
        "files_processed": 0,
        "files_total": existing.get("files_total", 0),
        "bytes_processed": 0,
        "total_bytes": existing.get("total_bytes", 0),
        "file_sizes": existing.get("file_sizes", []),
        "elapsed_sec": 0,
        "message": existing.get("message", "Indexing…"),
        "normalizer_hits": [],
    }

    proc = await asyncio.create_subprocess_exec(
        *cmd,
        env=env,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )

    # Store process handle for cancel endpoint
    _ingest_proc[corpus_name] = proc

    # Stream stderr lines as they arrive — tqdm writes progress to stderr.
    # tqdm emits two bar types:
    #   Discover: N file [...]           — file discovery phase, no chunks
    #   Process:  N%|...| N/N [..., chunks=N, processed=N, ...]  — actual indexing
    # We track the last Process line separately so the final summary uses
    # real chunk/file counts, not the Discover line which has no chunks.
    async def _stream_stderr() -> str:
        last_process_line = ""
        # Cache best seen values — used as fallback if last_line is empty or
        # a Discover line (no chunks=) when ingest completes faster than poll interval
        best_chunks = 0
        best_files_processed = 0
        best_files_total = 0
        assert proc.stderr is not None
        async for raw in proc.stderr:
            line = raw.decode(errors="replace").strip()
            if not line:
                continue
            elapsed = int(time.time() - start_time)

            # AIStudio (ingest-status freeze fix) — handle the [ingest] machine signals
            # FIRST and by SUBSTRING, before the tqdm-bar classification below.
            # pipeline.py renders a live tqdm bar even under this pipe; its
            # carriage-return clear()/refresh() can be glued onto the front of the
            # newline-terminated structured line (no intervening newline), so the
            # delivered line is "…<bar redraw>…[ingest] file_complete: …". A
            # startswith() check then fails and the signal is silently dropped (the
            # freeze bug — files_processed/elapsed/pct never advance). Substring match +
            # the re.search regexes below match through any bar prefix; doing this before
            # is_process_line stops a glued line that also looks like a Process line from
            # being swallowed by the tqdm-postfix branch. AIStudio_613 (the file_complete
            # signal) / AIStudio_722 (the TTY-gate that left the bar rendering in pipe mode).

            # Per-file completion signal — the PRIMARY source of
            # files_processed/bytes_processed/pct updates during ingest.
            # Shape: "[ingest] file_complete: N/M chunks=C bytes=B file=NAME"
            if "[ingest] file_complete:" in line:
                m_fc = re.search(
                    r"file_complete:\s*(\d+)/(\d+)\s+chunks=(\d+)\s+bytes=(\d+)",
                    line,
                )
                if m_fc:
                    n_done = int(m_fc.group(1))
                    n_total = int(m_fc.group(2))
                    c_total = int(m_fc.group(3))
                    b_total = int(m_fc.group(4))
                    cached_fc = _ingest_status.get(corpus_name, {})
                    # Self-correct d_observed from the observed chunks/bytes ratio.
                    d_obs_new = (
                        c_total / b_total
                        if b_total > 0
                        else cached_fc.get("d_observed", 0)
                    )
                    total_bytes_fc = cached_fc.get("total_bytes", 0)
                    pct_fc = (
                        min(99, round(c_total / (d_obs_new * total_bytes_fc) * 100))
                        if d_obs_new > 0 and total_bytes_fc > 0
                        else 0
                    )
                    mb_done_fc = b_total / (1024 * 1024)
                    mb_total_fc = total_bytes_fc / (1024 * 1024)
                    _ingest_status[corpus_name] = {
                        **cached_fc,
                        "status": "running",
                        "chunks_written": c_total,
                        "files_processed": n_done,
                        "files_total": n_total,
                        "bytes_processed": b_total,
                        "d_observed": d_obs_new,
                        "pct_complete": pct_fc,
                        "elapsed_sec": int(time.time() - start_time),
                        "message": (
                            f"{n_done} of {n_total} file(s) indexed. "
                            f"{mb_done_fc:.1f} / {mb_total_fc:.1f} MB = {pct_fc}%"
                        ),
                    }
                print(line, flush=True)  # operator log (API stdout)
                continue

            # AIStudio_680 — [ingest] normalizer: structured per-file line.
            # Shape: [ingest] normalizer: file=NAME format=FMT entity="ENTITY" year=YYYY chunks=N source=tag mismatch=false
            if "[ingest] normalizer:" in line:
                try:
                    _m_file = re.search(r"file=(\S+)", line)
                    _m_fmt = re.search(r"format=(\S+)", line)
                    _m_entity = re.search(r'entity="([^"]+)"', line)
                    _m_year = re.search(r"year=(\S+)", line)
                    _m_chunks = re.search(r"chunks=(\d+)", line)
                    _m_source = re.search(r"source=(\S+)", line)
                    _m_mismatch = re.search(r"mismatch=(\S+)", line)
                    if _m_entity:
                        _hit = {
                            "file": _m_file.group(1) if _m_file else "",
                            "format": _m_fmt.group(1) if _m_fmt else "",
                            "entity": _m_entity.group(1),
                            "year": _m_year.group(1) if _m_year else "",
                            "chunks": int(_m_chunks.group(1)) if _m_chunks else 0,
                            "source": _m_source.group(1) if _m_source else "",
                            "mismatch": _m_mismatch.group(1) == "true" if _m_mismatch else False,
                        }
                        _cached_norm = _ingest_status.get(corpus_name, {})
                        _existing_hits = list(_cached_norm.get("normalizer_hits", []))
                        _existing_hits.append(_hit)
                        _ingest_status[corpus_name] = {
                            **_cached_norm,
                            "normalizer_hits": _existing_hits,
                        }
                except Exception as _ne:
                    print(f"[ingest] normalizer parse warning: {_ne}", flush=True)
                print(line, flush=True)  # operator log (API stdout)
                continue

            # Any other [ingest] log line → API stdout, nothing to parse.
            if "[ingest]" in line:
                print(line, flush=True)
                continue

            # tqdm Process-bar lines — fallback progress source (best-effort; the bar's
            # \r-updates rarely surface at this newline iterator). Must start with
            # "Process"; the Discover bar has no chunks= field.
            is_process_line = line.startswith("Process") and (
                "chunks=" in line or re.search(r"\|\s*\d+/\d+", line)
            )
            if not is_process_line:
                continue

            last_process_line = line

            # Parse tqdm postfix fields: chunks=N, processed=N, failed=N
            chunks = 0
            files_processed = 0
            files_total = 0

            m_chunks = re.search(r"chunks=(\d+)", line)
            if m_chunks:
                chunks = int(m_chunks.group(1))

            m_proc = re.search(r"processed=(\d+)", line)
            if m_proc:
                files_processed = int(m_proc.group(1))

            # Parse "N/N" from tqdm bar: "143/143"
            m_total = re.search(r"\|\s*(\d+)/(\d+)", line)
            if m_total:
                files_processed = files_processed or int(m_total.group(1))
                files_total = int(m_total.group(2))

            # Update best seen values — monotonically increasing
            if chunks > best_chunks:
                best_chunks = chunks
            if files_processed > best_files_processed:
                best_files_processed = files_processed
            if files_total > best_files_total:
                best_files_total = files_total

            # Accumulate bytes_processed from pre-scan file sizes (alphabetical order)
            cached_now = _ingest_status.get(corpus_name, {})
            file_sizes_list = cached_now.get("file_sizes", [])
            total_bytes_now = cached_now.get("total_bytes", 0)
            bytes_completed = sum(file_sizes_list[:files_processed]) if file_sizes_list else 0

            # D_SEED: AIStudio_613 reconciled to 200 chunks/MB — midpoint between
            # PDF (~40 chunks/MB) and markdown (~1000 chunks/MB). Matches the seed
            # at line ~1078 (Qdrant polling path). Value matters less now that
            # self-correction writes d_observed back from observed ratios.
            # History: original was 20 (too optimistic → bar went backwards after file 1)
            # Session Apr12: divided by 4 → 5 (overcorrected — bar too slow)
            # Session Apr12 correction: ×16 → 80 (4× original, conservative for PDFs)
            # Session May10 (AIStudio_613): reconciled to 200 chunks/MB midpoint.
            D_SEED = 200 / (1024 * 1024)
            d_observed = cached_now.get("d_observed", D_SEED)
            if files_processed > 0 and bytes_completed > 0 and chunks > 0:
                d_observed = chunks / bytes_completed  # update with latest observed ratio

            # p% completion: how far through total expected chunks are we?
            if d_observed > 0 and total_bytes_now > 0:
                expected_total_chunks = d_observed * total_bytes_now
                pct = min(99, round(chunks / expected_total_chunks * 100))
            elif total_bytes_now > 0 and bytes_completed > 0:
                # Fallback: use byte-based ratio before D(k) is established
                pct = min(99, round(bytes_completed / total_bytes_now * 100))
            else:
                pct = 0

            active_file = files_processed + 1  # currently being processed
            mb_done = bytes_completed / (1024 * 1024)
            mb_total = total_bytes_now / (1024 * 1024)

            if total_bytes_now > 0:
                msg = f"{active_file} of {files_total} file(s) being indexed. {mb_done:.1f} / {mb_total:.1f} MB = {pct}% indexed"
            elif files_total > 0:
                msg = f"{active_file} of {files_total} file(s) being indexed"
            else:
                msg = "Indexing…"

            _ingest_status[corpus_name] = {
                "status": "running",
                "chunks_written": chunks,
                "files_processed": files_processed,
                "files_total": files_total,
                "bytes_processed": bytes_completed,
                "total_bytes": total_bytes_now,
                "file_sizes": file_sizes_list,
                "d_observed": d_observed,
                "pct_complete": pct,
                "elapsed_sec": elapsed,
                "message": msg,
                "_best_chunks": best_chunks,
                "_best_files_processed": best_files_processed,
                "_best_files_total": best_files_total,
            }
        return last_process_line

    # Capture stdout — __main__.py writes a JSON result object with full ingest stats
    async def _capture_stdout() -> str:
        assert proc.stdout is not None
        lines = []
        async for raw in proc.stdout:
            lines.append(raw.decode(errors="replace"))
        return "".join(lines)

    last_line, stdout_text = await asyncio.gather(_stream_stderr(), _capture_stdout())
    await proc.wait()

    elapsed = int(time.time() - start_time)
    mins, secs = divmod(elapsed, 60)
    elapsed_str = f"{mins}m {secs}s" if mins else f"{secs}s"

    if proc.returncode == 0:
        # Parse the JSON result from stdout — __main__.py always writes full stats there.
        # Fall back to tqdm-derived values if JSON parse fails (e.g. subprocess printed
        # unexpected output before the JSON).
        cached = _ingest_status.get(corpus_name, {})
        final_chunks = 0
        final_new = 0
        final_skipped = 0
        final_total = 0

        try:
            result_json = json.loads(stdout_text.strip()) if stdout_text.strip() else {}
            result = result_json.get("result", {})
            final_new = int(result.get("files_processed", 0))
            final_skipped = int(result.get("files_skipped_unchanged", 0))
            final_chunks = int(result.get("chunks_written", 0))
            final_total = final_new + final_skipped
        except Exception:
            # Fallback: use tqdm-parsed values from streaming
            m_chunks = re.search(r"chunks=(\d+)", last_line)
            if m_chunks:
                final_chunks = int(m_chunks.group(1))
            m_total = re.search(r"\|\s*(\d+)/(\d+)", last_line)
            if m_total:
                final_total = int(m_total.group(2))
            if final_total == 0:
                final_total = cached.get("_best_files_total", 0)
            final_new = final_total  # unknown split — show as all new

        # Build completion summary — always include new/skipped/total for machine parseability
        if final_skipped > 0 and final_new == 0:
            summary = f"0 new · {final_skipped} skipped · {final_total} total · {elapsed_str}"
        elif final_skipped > 0:
            summary = (
                f"{final_new} new · {final_skipped} skipped · {final_total} total · {elapsed_str}"
            )
        else:
            summary = f"{final_new} new · 0 skipped · {final_total} total · {elapsed_str}"

        _ingest_status[corpus_name] = {
            "status": "done",
            "chunks_written": final_chunks,
            "files_processed": final_total,
            "files_total": final_total,
            "elapsed_sec": elapsed,
            "elapsed_str": elapsed_str,
            "summary": summary,
            "message": summary,
            "normalizer_hits": cached.get("normalizer_hits", []),
        }
        print(f"[ingest] '{corpus_name}' complete — {summary}")

        # AIStudio_270: write ingestion metadata to corpus_metadata.yaml
        try:
            _repo = _get_repo_root()
            _meta_path = (
                _repo / "data" / "corpora" / corpus_name / f"{corpus_name}_corpus_metadata.yaml"
            )
            if _meta_path.exists():
                with open(_meta_path) as _f:
                    _meta = _yaml.safe_load(_f) or {}
            else:
                _meta = {"corpus_name": corpus_name}
            now_iso = _dt.now().isoformat(timespec="seconds")
            _meta["last_ingested_at"] = now_iso
            _meta["last_updated"] = _dt.now().date().isoformat()
            _meta["ingest_duration_seconds"] = elapsed
            _meta["last_ingest_chunks"] = final_chunks
            _meta["last_ingest_files"] = final_total
            # avg_seconds_per_file — useful for estimating future ingest times
            if final_total > 0:
                _meta["avg_seconds_per_file"] = round(elapsed / final_total, 2)
            # Ensure schema fields present
            if "schema_version" not in _meta:
                _meta["schema_version"] = "1.0"
            if "files" not in _meta or not isinstance(_meta.get("files"), dict):
                _meta["files"] = {}
            if "deleted_files" not in _meta or not isinstance(_meta.get("deleted_files"), dict):
                _meta["deleted_files"] = {}
            # Parse per-file stats from stdout JSON
            try:
                _result_json = json.loads(stdout_text.strip()) if stdout_text.strip() else {}
                _file_stats = _result_json.get("result", {}).get("file_stats") or {}
                # Build normalizer prefix lookup from normalizer_hits accumulated during ingest
                _norm_hits = {h["file"]: h for h in cached.get("normalizer_hits", [])}
                for _fname, _fdata in _file_stats.items():
                    _norm = _norm_hits.get(_fname, {})
                    # Derive file_type label from extension
                    _ext = Path(_fname).suffix.lower()
                    _file_type_labels = {
                        ".xhtml": "ESEF iXBRL", ".htm": "SEC XBRL", ".html": "SEC XBRL",
                        ".pdf": "PDF", ".md": "Markdown", ".txt": "Text",
                        ".docx": "Word", ".xlsx": "Excel",
                    }
                    _file_type = _file_type_labels.get(_ext, _ext.lstrip(".").upper())
                    _entry = {
                        "file_type": _file_type,
                        "size_bytes": _fdata.get("size_bytes", 0),
                        "chunks": _fdata.get("chunks", 0),
                        "duration_sec": _fdata.get("duration_sec", 0),
                        "ingested_at": _fdata.get("ingested_at", now_iso),
                        # Normalizer fields written by pipeline.py into file_stats
                        "normalizer_entity": _fdata.get("normalizer_entity") or "",
                        "normalizer_year": _fdata.get("normalizer_year") or "",
                        "normalizer_source": _fdata.get("normalizer_source") or "",
                        "normalizer_mismatch": _fdata.get("normalizer_mismatch") or False,
                    }
                    _meta["files"][_fname] = _entry
            except Exception as _fe:
                print(f"[ingest] warning: could not parse file_stats: {_fe}")
            with open(_meta_path, "w") as _f:
                _f.write(f"# {corpus_name}_corpus_metadata.yaml\n")
                _yaml.dump(_meta, _f, allow_unicode=True, default_flow_style=False, sort_keys=False)
        except Exception as _e:
            print(
                f"[ingest] warning: could not write ingest metadata to corpus_metadata.yaml: {_e}"
            )

        _ingest_proc.pop(corpus_name, None)
    else:
        _ingest_status[corpus_name] = {
            "status": "error",
            "chunks_written": 0,
            "files_processed": 0,
            "files_total": 0,
            "elapsed_sec": elapsed,
            "message": "Ingestion failed — check server logs",
        }
        _ingest_proc.pop(corpus_name, None)
        print(f"[ingest] '{corpus_name}' failed after {elapsed_str}:\n{last_line}")


@app.post("/corpus/{corpus_name}/upload")
async def upload_to_corpus(
    corpus_name: str,
    file: UploadFile = File(...),  # noqa: B008
) -> dict[str, Any]:
    """
    Upload a file to the specified corpus.
    Note: This saves the file but does NOT automatically ingest it.
    You must run the ingest command separately to process and embed the file.
    """
    _require_corpus(corpus_name)

    # Validate file extension against supported types before saving.
    # Must stay in sync with SUPPORTED_EXTS in src/local_llm_bot/app/ingest/loaders.py.
    # Prevents unsupported files (e.g. .yaml, .json) from landing in uploads/
    # and appearing in the file list with N/A chunks (AIStudio_517).
    allowed_extensions = SUPPORTED_EXTS
    file_ext = Path(file.filename).suffix.lower() if file.filename else ""
    if file_ext not in allowed_extensions:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type '{file_ext}'. Allowed: {', '.join(sorted(allowed_extensions))}",
        )

    repo_root = _get_repo_root()
    paths = corpus_paths(repo_root=repo_root, corpus=corpus_name)

    # Create uploads directory in corpus
    uploads_dir = paths["uploads"]
    uploads_dir.mkdir(parents=True, exist_ok=True)

    # Save uploaded file
    file_path = uploads_dir / file.filename

    try:
        # Read file content
        content = await file.read()

        # Write to disk
        with open(file_path, "wb") as f:
            f.write(content)

        file_size = len(content)

        # Write stub entry to corpus_metadata.yaml so the UI can show file type + size
        # immediately after upload, before ingest runs. Ingest will fill in remaining fields.
        _file_type_map = {
            ".xhtml": "ESEF iXBRL", ".htm": "SEC XBRL", ".html": "SEC XBRL",
            ".pdf": "PDF", ".md": "Markdown", ".txt": "Text",
            ".docx": "Word", ".xlsx": "Excel",
        }
        try:
            _meta_path = (
                paths["base"] / f"{corpus_name}_corpus_metadata.yaml"
            )
            if _meta_path.exists():
                with open(_meta_path) as _f:
                    _meta = _yaml.safe_load(_f) or {}
            else:
                _meta = {"corpus_name": corpus_name, "schema_version": "1.0"}
            if "files" not in _meta or not isinstance(_meta.get("files"), dict):
                _meta["files"] = {}
            # Only write stub if no entry exists yet (don't clobber post-ingest data)
            if file.filename not in _meta["files"]:
                _meta["files"][file.filename] = {
                    "file_type": _file_type_map.get(file_ext, file_ext.lstrip(".").upper()),
                    "size_bytes": file_size,
                    "chunks": None,
                    "duration_sec": None,
                    "ingested_at": None,
                }
                with open(_meta_path, "w") as _f:
                    _f.write(f"# {corpus_name}_corpus_metadata.yaml\n")
                    _yaml.dump(_meta, _f, allow_unicode=True, default_flow_style=False, sort_keys=False)
        except Exception:
            pass  # Metadata stub failure is non-fatal — upload still succeeds

        # File saved only — ingest triggered separately via POST /corpus/{name}/ingest
        # Batch uploads must NOT each spawn their own ingest: concurrent processes
        # stomp on each other in Qdrant, causing false error status.
        return {
            "status": "saved",
            "message": "File saved. Call /ingest to index.",
            "filename": file.filename,
            "file_path": str(file_path),
            "size_bytes": file_size,
            "content_type": file.content_type,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to upload file: {str(e)}") from e


@app.post("/corpus/{corpus_name}/ingest")
async def trigger_ingest(
    corpus_name: str,
    body: Annotated[dict | None, Body()] = None,
) -> dict[str, Any]:
    """
    Trigger an ingest pass.

    Body (optional): {"files": ["a.htm", "b.htm"]}
      - present → ingest ONLY those files (always re-embedded); all other files in
        uploads/ (indexed or parked) are left untouched. Pre-scan + denominators
        reflect only the selected subset.
      - absent  → whole-corpus pass over uploads/ (legacy behavior).
    Guards against concurrent runs (returns already_running if busy).
    """
    _require_corpus(corpus_name)
    repo_root = _get_repo_root()
    paths = corpus_paths(repo_root=repo_root, corpus=corpus_name)
    uploads_dir = paths["uploads"]

    # Optional explicit allowlist (basenames) from request body.
    only_files: set[str] | None = None
    if isinstance(body, dict) and body.get("files"):
        only_files = {str(n).strip() for n in body["files"] if str(n).strip()}
        if not only_files:
            only_files = None

    # Clear any stale status from previous run — prevents stale chunk/file counts
    # from leaking into the new run if pre-scan or tqdm stream hasn't fired yet.
    # Must happen before the already_running check so we don't clear an active run.
    if _ingest_status.get(corpus_name, {}).get("status") != "running":
        _ingest_status.pop(corpus_name, None)

    if _ingest_status.get(corpus_name, {}).get("status") == "running":
        return {"status": "already_running", "message": "Ingestion already in progress."}

    # Pre-scan uploads dir — collect file sizes in alphabetical order.
    # Gives us files_total and total_bytes before subprocess starts,
    # so the status endpoint can show meaningful ratios from second 0.
    print(f"[ingest] pre-scan path: {uploads_dir} exists={uploads_dir.exists()}", flush=True)
    if uploads_dir.exists():
        files_found = [p for p in uploads_dir.iterdir() if p.is_file()]
        print(
            f"[ingest] pre-scan found {len(files_found)} total files, extensions: {set(p.suffix.lower() for p in files_found)}",
            flush=True,
        )
    pre_scan: list[tuple[str, int]] = []
    print(f"[ingest] pre-scan: uploads_dir={uploads_dir} exists={uploads_dir.exists()}", flush=True)
    if uploads_dir.exists() and uploads_dir.is_dir():
        try:
            all_files = [
                (p.name, p.suffix.lower(), p.stat().st_size)
                for p in uploads_dir.iterdir()
                if p.is_file()
            ]
            print(
                f"[ingest] pre-scan: found {len(all_files)} files: {[(n, e) for n, e, _ in all_files[:3]]}",
                flush=True,
            )
            print(f"[ingest] pre-scan: SUPPORTED_EXTS={SUPPORTED_EXTS}", flush=True)
            pre_scan = sorted(
                [(name, sz) for name, ext, sz in all_files if ext in SUPPORTED_EXTS],
                key=lambda x: x[0],
            )
            # Restrict pre-scan to the selected files so files_total / total_bytes /
            # file_sizes reflect ONLY what will actually be ingested. Without this the
            # progress bar denominator would be the whole corpus while the run does a subset.
            if only_files is not None:
                pre_scan = [(name, sz) for name, sz in pre_scan if name in only_files]
            print(
                f"[ingest] pre-scan: {len(pre_scan)} supported files, total_bytes={sum(sz for _, sz in pre_scan)}",
                flush=True,
            )
        except Exception as _pre_err:
            print(f"[ingest] pre-scan error for {corpus_name}: {_pre_err}", flush=True)
    else:
        print(f"[ingest] pre-scan: uploads_dir missing: {uploads_dir}", flush=True)
    files_total = len(pre_scan)
    total_bytes = sum(sz for _, sz in pre_scan)
    file_sizes = [sz for _, sz in pre_scan]  # ordered, used to accumulate bytes_processed

    _ingest_status[corpus_name] = {
        "status": "running",
        "chunks_written": 0,
        "files_processed": 0,
        "files_total": files_total,
        "bytes_processed": 0,
        "total_bytes": total_bytes,
        "file_sizes": file_sizes,
        "elapsed_sec": 0,
        "message": f"0 of {files_total} file(s) being indexed. 0 / {total_bytes / (1024 * 1024):.1f} MB = 0% indexed",
    }

    asyncio.create_task(_run_ingest_background(corpus_name, uploads_dir, only_files))
    return {"status": "started", "message": f"Ingestion started for corpus '{corpus_name}'."}


class CreateCorpusRequest(BaseModel):
    name: str
    short_description: str = ""
    description: str = ""
    content_summary: str = ""
    search_guidance: str = ""
    default_top_k: int | None = None
    default_temperature: float | None = None
    default_hybrid_alpha: float | None = None
    default_min_score: float | None = None


@app.get("/corpus/{corpus_name}/ingest-status")
async def get_ingest_status(corpus_name: str) -> dict:
    """Poll ingestion progress. status: idle|running|done|error.

    Augments in-memory tqdm state with live Qdrant points_count so the
    UI gets real chunk progress even between tqdm stderr line emissions.
    """
    cached = _ingest_status.get(
        corpus_name,
        {"status": "idle", "chunks_written": 0, "message": "No recent ingestion"},
    )

    # For running ingests: query Qdrant directly for live chunk count.
    # tqdm stderr only emits on file completion (every 60s+ for large files).
    # Qdrant points_count updates every upsert batch (~0.6s) — far more granular.
    if cached.get("status") == "running":
        try:
            from qdrant_client import QdrantClient

            qc = QdrantClient(host="localhost", port=6333)
            # Only read from the specific corpus collection — never inherit from other collections
            collection_name = f"aistudio_{corpus_name}"
            existing = [c.name for c in qc.get_collections().collections]
            if collection_name in existing:
                col_info = qc.get_collection(collection_name)
                live_chunks = col_info.points_count or 0
                if live_chunks > cached.get("chunks_written", 0):
                    cached = {**cached, "chunks_written": live_chunks}
                    fp = cached.get("files_processed", 0)
                    ft = cached.get("files_total", 0)
                    file_sizes_c = cached.get("file_sizes", [])
                    total_bytes_c = cached.get("total_bytes", 0)
                    bytes_done = sum(file_sizes_c[:fp]) if file_sizes_c else 0
                    # AIStudio_613: reconciled D_SEED to 200 chunks/MB — midpoint
                    # between PDF (~40 chunks/MB) and markdown (~1000 chunks/MB).
                    # Value matters less now that self-correction (below) writes back.
                    _D_SEED = 200 / (1024 * 1024)
                    d_obs = cached.get("d_observed", _D_SEED)
                    # AIStudio_613: self-correct d_observed from observed live ratio.
                    # Without this writeback the seed never updates and pct stays
                    # stuck (bug c). Clamp to [1e-5, 1e-2] chunks/byte to reject
                    # divide-by-zero artifacts and pathological intermediate states.
                    bytes_done_c = cached.get("bytes_processed", 0)
                    if bytes_done_c > 0 and live_chunks > 0:
                        d_obs_observed = live_chunks / bytes_done_c
                        if 1e-5 <= d_obs_observed <= 1e-2:
                            d_obs = d_obs_observed
                            cached["d_observed"] = d_obs
                    # Use D(k) for pct if available, else byte ratio
                    if d_obs > 0 and total_bytes_c > 0:
                        raw_pct = live_chunks / (d_obs * total_bytes_c) * 100
                        pct = min(99, round(raw_pct))
                        bytes_est = min(total_bytes_c, live_chunks / d_obs)
                        cached["bytes_processed"] = int(bytes_est)
                    elif total_bytes_c > 0 and bytes_done > 0:
                        pct = min(99, round(bytes_done / total_bytes_c * 100))
                    else:
                        pct = 0
                    cached["pct_complete"] = pct
                    if total_bytes_c > 0 and ft > 0:
                        mb_done = bytes_done / (1024 * 1024)
                        mb_total = total_bytes_c / (1024 * 1024)
                        active = fp + 1
                        cached["message"] = (
                            f"{active} of {ft} file(s) being indexed. {mb_done:.1f} / {mb_total:.1f} MB = {pct}% indexed"
                        )
                    elif ft > 0:
                        cached["message"] = f"{fp + 1} of {ft} file(s) being indexed"
            else:
                # Collection not yet created — return 0, never inherit stale data
                cached = {**cached, "chunks_written": 0}
        except Exception:
            pass  # Fall back to cached tqdm data if Qdrant unreachable

    return cached


@app.post("/corpus/{corpus_name}/ingest-cancel")
async def cancel_ingest(corpus_name: str) -> dict[str, Any]:
    """Cancel a running ingest for the given corpus.

    Kills the ingest subprocess. Qdrant state is preserved as-is —
    files that completed before cancel remain indexed and will be
    skipped on the next ingest run. The in-flight file may have
    partial chunks; a future full re-ingest will clean these up.
    """
    _require_corpus(corpus_name)
    proc = _ingest_proc.get(corpus_name)
    cached = _ingest_status.get(corpus_name, {})

    if not proc or cached.get("status") != "running":
        return {"status": "not_running", "message": "No active ingest to cancel"}

    try:
        proc.kill()
        await proc.wait()
    except Exception:
        pass

    files_completed = cached.get("files_processed", 0)
    _ingest_proc.pop(corpus_name, None)
    _ingest_status[corpus_name] = {
        "status": "cancelled",
        "chunks_written": cached.get("chunks_written", 0),
        "files_processed": files_completed,
        "files_completed": files_completed,
        "files_total": cached.get("files_total", 0),
        "message": f"Cancelled — {files_completed} file{'s' if files_completed != 1 else ''} completed",
    }
    print(f"[ingest] '{corpus_name}' cancelled — {files_completed} files completed")
    return {"status": "cancelled", "files_completed": files_completed}


@app.post("/corpus/create")
async def create_corpus(request: CreateCorpusRequest) -> dict[str, Any]:
    """
    Create a new corpus directory structure.
    """
    name = request.name

    # Validate corpus name
    if not name or not name.replace("_", "").replace("-", "").isalnum():
        raise HTTPException(
            status_code=400,
            detail="Corpus name must contain only letters, numbers, hyphens, and underscores",
        )

    if corpus_exists(find_repo_root(Path(__file__)), name):
        raise HTTPException(status_code=409, detail=f"Corpus '{name}' already exists")

    repo_root = _get_repo_root()
    paths = corpus_paths(repo_root=repo_root, corpus=name)

    try:
        # Create corpus directory structure
        corpus_dir = paths["base"]
        corpus_dir.mkdir(parents=True, exist_ok=True)

        # Create uploads/ and trash/ as siblings (trash is never inside uploads/)
        paths["uploads"].mkdir(exist_ok=True)
        paths["trash"].mkdir(exist_ok=True)

        # Create empty index file
        index_file = paths["index"]
        index_file.parent.mkdir(parents=True, exist_ok=True)
        index_file.touch()

        # Create corpus_metadata.yaml with full schema
        corpus_meta_path = corpus_dir / f"{name}_corpus_metadata.yaml"
        from datetime import date as _date

        _meta_content = {
            "schema_version": "1.0",
            "corpus_name": name,
            "last_updated": _date.today().isoformat(),
            "short_description": request.short_description or "",
            "description": request.description or "",
            "content_summary": request.content_summary or "",
            "search_guidance": request.search_guidance or "",
        }
        # AIStudio_738C: persist user-set query defaults if provided at creation time
        if request.default_top_k is not None:
            _meta_content["default_top_k"] = request.default_top_k
        if request.default_temperature is not None:
            _meta_content["default_temperature"] = request.default_temperature
        if request.default_hybrid_alpha is not None:
            _meta_content["default_hybrid_alpha"] = request.default_hybrid_alpha
        if request.default_min_score is not None:
            _meta_content["default_min_score"] = request.default_min_score
        corpus_meta_path.write_text(
            f"# {name}_corpus_metadata.yaml\n"
            f"# Corpus metadata — loaded by api.py at query time\n"
            f"# Edit fields to improve retrieval quality for this corpus\n\n"
        )
        with open(corpus_meta_path, "a") as _mf:
            _yaml.dump(
                _meta_content, _mf, allow_unicode=True, default_flow_style=False, sort_keys=False
            )

        return {
            "status": "success",
            "message": f"Corpus '{name}' created successfully",
            "name": name,
            "paths": {
                "base": str(corpus_dir),
                "uploads": str(corpus_dir / "uploads"),
                "index": str(index_file),
            },
            "next_steps": f"Upload files to corpus or add documents to {corpus_dir / 'uploads'}",
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to create corpus: {str(e)}") from e


@app.post("/corpus/{corpus_name}/rename")
async def rename_corpus(corpus_name: str, request: Request) -> dict[str, Any]:
    """
    Rename a corpus: moves directory on disk, renames corpus_metadata.yaml,
    deletes old Qdrant collection, and triggers background re-ingest.
    Body: {"new_name": "my_new_corpus_name"}
    """
    body = await request.json()
    new_name = body.get("new_name", "").strip()

    if not new_name or not new_name.replace("_", "").replace("-", "").isalnum():
        raise HTTPException(
            status_code=400,
            detail="Corpus name must contain only letters, numbers, hyphens, and underscores",
        )

    repo_root = _get_repo_root()

    if not corpus_exists(repo_root, corpus_name):
        raise HTTPException(status_code=404, detail=f"Corpus '{corpus_name}' not found")

    if corpus_exists(repo_root, new_name):
        raise HTTPException(status_code=409, detail=f"Corpus '{new_name}' already exists")

    old_paths = corpus_paths(repo_root=repo_root, corpus=corpus_name)
    old_dir = old_paths["base"]
    new_dir = repo_root / "data" / "corpora" / new_name

    try:
        # 1. Rename directory on disk
        old_dir.rename(new_dir)

        # 2. Rename corpus_metadata.yaml inside new directory
        old_meta = new_dir / f"{corpus_name}_corpus_metadata.yaml"
        new_meta = new_dir / f"{new_name}_corpus_metadata.yaml"
        if old_meta.exists():
            old_meta.rename(new_meta)
            # Update corpus_name field inside meta file
            content = new_meta.read_text()
            content = content.replace(f"corpus_name: {corpus_name}", f"corpus_name: {new_name}")
            new_meta.write_text(content)

        # 3. Delete old Qdrant collection
        try:
            from qdrant_client import QdrantClient

            qc = QdrantClient(host="localhost", port=6333)
            qc.delete_collection(f"aistudio_{corpus_name}")
        except Exception as e:
            print(f"[rename_corpus] Qdrant cleanup warning: {e}")

        # 4. Clear any in-memory ingest status for old corpus
        _ingest_status.pop(corpus_name, None)

        # 5. Trigger background re-ingest on new corpus
        new_uploads = new_dir / "uploads"
        if new_uploads.exists() and any(new_uploads.iterdir()):
            import asyncio

            asyncio.create_task(_run_ingest_background(new_name, str(new_uploads)))

        return {
            "status": "success",
            "message": f"Corpus '{corpus_name}' renamed to '{new_name}'",
            "old_name": corpus_name,
            "new_name": new_name,
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to rename corpus: {str(e)}") from e


@app.delete("/corpus/{corpus_name}")
async def delete_corpus(corpus_name: str, confirm: str = "") -> dict[str, Any]:
    """
    Move a corpus to Mac Trash (~/.Trash) and delete its Qdrant collection.
    Requires confirm=yes query parameter.
    To restore: move folder from ~/.Trash back to data/corpora/ and re-ingest.
    See HOW_TO.md for recovery instructions.
    """
    if confirm.lower() != "yes":
        raise HTTPException(
            status_code=400, detail="Confirmation required. Pass ?confirm=yes to proceed."
        )

    _require_corpus(corpus_name)

    if corpus_name == "default":
        raise HTTPException(status_code=403, detail="Cannot delete the default corpus")

    repo_root = _get_repo_root()
    paths = corpus_paths(repo_root=repo_root, corpus=corpus_name)
    corpus_dir = paths["base"]

    # Step 1: Delete Qdrant collection
    try:
        from qdrant_client import QdrantClient

        qc = QdrantClient(host="localhost", port=6333)
        qc.delete_collection(f"aistudio_{corpus_name}")
    except Exception as e:
        print(f"[delete_corpus] Qdrant cleanup warning: {e}")

    # Clear in-memory ingest status — prevents stale data from leaking into next ingest
    _ingest_status.pop(corpus_name, None)
    _ingest_proc.pop(corpus_name, None)

    # Step 2: Move corpus folder to Mac Trash (recoverable)
    try:
        trash_dir = Path.home() / ".Trash"
        trash_dir.mkdir(exist_ok=True)
        dest = trash_dir / f"AIStudio_{corpus_name}"
        if dest.exists():
            dest = trash_dir / f"AIStudio_{corpus_name}_{int(time.time())}"
        if corpus_dir.exists():
            shutil.move(str(corpus_dir), str(dest))

        return {
            "status": "success",
            "message": f"Corpus '{corpus_name}' moved to Trash. To restore, see HOW_TO.md.",
            "name": corpus_name,
            "trash_path": str(dest),
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to delete corpus: {str(e)}") from e


@app.get("/corpus/{corpus_name}/file/{filename:path}/md5")
async def get_file_md5(corpus_name: str, filename: str) -> dict[str, Any]:
    """
    Return the MD5 hash of an already-indexed file.

    Scrolls Qdrant for chunks where source_path ends with the filename,
    extracts the md5 field from the payload of the first matching chunk.

    Returns:
        {"filename": filename, "md5": "<hex>"}  if found
        404  if the file is not indexed in this corpus
    """
    _require_corpus(corpus_name)
    collection_name = f"aistudio_{corpus_name}"

    try:
        from qdrant_client import QdrantClient
        from qdrant_client.models import PayloadSelectorInclude

        client = QdrantClient(host="localhost", port=6333)
        existing = [c.name for c in client.get_collections().collections]
        if collection_name not in existing:
            raise HTTPException(status_code=404, detail=f"Corpus '{corpus_name}' not indexed")

        # Scroll in pages — stop as soon as we find a chunk with an md5 field
        offset = None
        while True:
            results, next_offset = client.scroll(
                collection_name=collection_name,
                limit=100,
                offset=offset,
                with_payload=PayloadSelectorInclude(include=["source_path", "md5"]),
                with_vectors=False,
            )
            for point in results:
                payload = point.payload or {}
                sp = payload.get("source_path", "")
                # Match by filename suffix — source_path is absolute, filename is basename
                if sp.endswith(f"/{filename}") or sp.endswith(f"\\{filename}") or sp == filename:
                    md5 = payload.get("md5", "")
                    if md5:
                        return {"filename": filename, "md5": md5}
            if next_offset is None:
                break
            offset = next_offset

        raise HTTPException(
            status_code=404, detail=f"File '{filename}' not found in corpus '{corpus_name}'"
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"MD5 lookup failed: {str(e)}") from e


@app.delete("/corpus/{corpus_name}/file/{filename:path}/chunks")
async def delete_file_chunks_only(corpus_name: str, filename: str) -> dict[str, Any]:
    """Remove a file's Qdrant chunks without moving the file to trash.
    Used for reingest: wipe stale chunks then re-trigger ingest so the file
    is re-embedded with current normalizer settings. File stays in uploads/.
    """
    _require_corpus(corpus_name)
    repo_root = _get_repo_root()
    paths = corpus_paths(repo_root=repo_root, corpus=corpus_name)
    uploads_dir = paths["uploads"]
    file_path = uploads_dir / filename

    if not file_path.exists():
        raise HTTPException(status_code=404, detail=f"File not found: {filename}")

    try:
        file_path.resolve().relative_to(uploads_dir.resolve())
    except ValueError as e:
        raise HTTPException(status_code=403, detail="Access denied") from e

    abs_file_path = str(file_path.resolve())
    deleted_chunks = 0
    try:
        from qdrant_client import QdrantClient
        from qdrant_client.models import FieldCondition, Filter, MatchValue

        qc = QdrantClient(host="localhost", port=6333)
        collection = f"aistudio_{corpus_name}"
        scroll_result = qc.scroll(
            collection_name=collection,
            scroll_filter=Filter(
                must=[FieldCondition(key="source_path", match=MatchValue(value=abs_file_path))]
            ),
            limit=10000,
            with_payload=False,
        )
        point_ids = [p.id for p in scroll_result[0]]
        deleted_chunks = len(point_ids)
        if point_ids:
            qc.delete(collection_name=collection, points_selector=point_ids)
    except Exception as e:
        print(f"[delete_chunks] Qdrant warning: {e}")

    # Clear file entry from corpus_metadata.yaml so it re-ingests cleanly
    try:
        _repo = _get_repo_root()
        _meta_path = _repo / "data" / "corpora" / corpus_name / f"{corpus_name}_corpus_metadata.yaml"
        if _meta_path.exists():
            with open(_meta_path) as _f:
                _meta = _yaml.safe_load(_f) or {}
            if "files" in _meta and filename in _meta["files"]:
                # Keep file_type and size_bytes (known pre-ingest), clear ingest fields
                _stub = _meta["files"][filename]
                _meta["files"][filename] = {
                    "file_type": _stub.get("file_type", ""),
                    "size_bytes": _stub.get("size_bytes", 0),
                    "chunks": None,
                    "duration_sec": None,
                    "ingested_at": None,
                    "normalizer_entity": None,
                    "normalizer_year": None,
                    "normalizer_source": None,
                    "normalizer_mismatch": None,
                }
            with open(_meta_path, "w") as _f:
                _f.write(f"# {corpus_name}_corpus_metadata.yaml\n")
                _yaml.dump(_meta, _f, allow_unicode=True, default_flow_style=False, sort_keys=False)
    except Exception:
        pass

    return {
        "status": "ok",
        "filename": filename,
        "chunks_removed": deleted_chunks,
        "message": f"'{filename}' chunks removed from index. File retained for reingest.",
    }


@app.delete("/corpus/{corpus_name}/file/{filename:path}")
async def delete_file_from_corpus(corpus_name: str, filename: str) -> dict[str, Any]:
    """Move a file to trash and remove its Qdrant chunks surgically."""
    _require_corpus(corpus_name)
    repo_root = _get_repo_root()
    paths = corpus_paths(repo_root=repo_root, corpus=corpus_name)
    uploads_dir = paths["uploads"]
    file_path = uploads_dir / filename

    if not file_path.exists():
        raise HTTPException(status_code=404, detail=f"File not found: {filename}")

    try:
        file_path.resolve().relative_to(uploads_dir.resolve())
    except ValueError as e:
        raise HTTPException(status_code=403, detail="Access denied") from e

    # Use resolved absolute path — must match how pipeline.py stores source_path in Qdrant.
    # pipeline.py uses str(file_path.resolve()) as the chunk source_path key.
    abs_file_path = str(file_path.resolve())

    deleted_chunks = 0
    try:
        from qdrant_client import QdrantClient
        from qdrant_client.models import FieldCondition, Filter, MatchValue

        qc = QdrantClient(host="localhost", port=6333)
        collection = f"aistudio_{corpus_name}"
        scroll_result = qc.scroll(
            collection_name=collection,
            scroll_filter=Filter(
                must=[FieldCondition(key="source_path", match=MatchValue(value=abs_file_path))]
            ),
            limit=10000,
            with_payload=False,
        )
        point_ids = [p.id for p in scroll_result[0]]
        deleted_chunks = len(point_ids)
        if point_ids:
            qc.delete(collection_name=collection, points_selector=point_ids)
    except Exception as e:
        print(f"[delete_file] Qdrant warning: {e}")

    # Housekeeping: remove from JSONL audit logs using resolved path.
    # These are legacy artifacts — not used for skip decisions (Qdrant is the authority).
    manifest_path = paths["manifest"]
    if manifest_path.exists():
        kept = [ln for ln in manifest_path.read_text().splitlines() if abs_file_path not in ln]
        manifest_path.write_text("\n".join(kept) + ("\n" if kept else ""))

    index_path = paths.get("index")
    if index_path and Path(index_path).exists():
        kept = [ln for ln in Path(index_path).read_text().splitlines() if abs_file_path not in ln]
        Path(index_path).write_text("\n".join(kept) + ("\n" if kept else ""))

    # Move file to corpus-level trash/ (sibling of uploads/, never inside it).
    # This ensures pipeline.py ingest (rooted at uploads/) never sees deleted files.
    trash_dir = paths["trash"]
    trash_dir.mkdir(parents=True, exist_ok=True)
    trash_path = trash_dir / filename
    # Overwrite any existing file with the same name — it is a prior version of the same file
    if trash_path.exists():
        trash_path.unlink()
    shutil.move(str(file_path), str(trash_path))

    # Update corpus_metadata.yaml — archive deleted file stats, reflect file count change
    try:
        _repo = _get_repo_root()
        _meta_path = (
            _repo / "data" / "corpora" / corpus_name / f"{corpus_name}_corpus_metadata.yaml"
        )
        if _meta_path.exists():
            with open(_meta_path) as _f:
                _meta = _yaml.safe_load(_f) or {}
        else:
            _meta = {"corpus_name": corpus_name}
        # Ensure files/deleted_files dicts exist
        if "files" not in _meta or not isinstance(_meta.get("files"), dict):
            _meta["files"] = {}
        if "deleted_files" not in _meta or not isinstance(_meta.get("deleted_files"), dict):
            _meta["deleted_files"] = {}
        # Archive file stats to deleted_files before removing from files
        _now = _dt.now().isoformat(timespec="seconds")
        if filename in _meta["files"]:
            _archived = dict(_meta["files"].pop(filename))
            _archived["deleted_at"] = _now
            _meta["deleted_files"][filename] = _archived
        else:
            # No per-file stats tracked yet — archive minimal record
            _meta["deleted_files"][filename] = {
                "deleted_at": _now,
                "chunks_removed": deleted_chunks,
            }
        # Recount files on disk after deletion
        _uploads = paths["uploads"]
        _file_count = (
            len([f for f in _uploads.iterdir() if f.is_file() and not f.name.startswith(".")])
            if _uploads.exists()
            else 0
        )
        _meta["last_file_change_at"] = _now
        _meta["last_file_change"] = f"deleted: {filename}"
        _meta["file_count_after_change"] = _file_count
        _meta["last_updated"] = _dt.now().date().isoformat()
        with open(_meta_path, "w") as _f:
            _f.write(f"# {corpus_name}_corpus_metadata.yaml\n")
            _yaml.dump(_meta, _f, allow_unicode=True, default_flow_style=False, sort_keys=False)
    except Exception as _e:
        print(f"[delete_file] warning: could not update corpus_metadata.yaml: {_e}")

    return {
        "status": "success",
        "message": f"'{filename}' moved to trash. {deleted_chunks} chunks removed.",
        "filename": filename,
        "chunks_removed": deleted_chunks,
    }


@app.get("/about")
async def get_about() -> dict[str, Any]:
    """Serve about.md content for the About modal.
    Rewrites relative markdown links to absolute file:// paths so they work
    offline without any external dependency."""
    import re

    repo_root = _get_repo_root()
    for fname in ["about.md", "ABOUT.md"]:
        p = repo_root / fname
        if p.exists():
            content = p.read_text(encoding="utf-8")

            # Rewrite relative links [text](relative/path) → [text](file:///abs/path)
            def rewrite_link(m: re.Match) -> str:
                text, href = m.group(1), m.group(2)
                if href.startswith(("http", "mailto", "file://")):
                    return m.group(0)  # leave absolute links alone
                # Split anchor from path before resolving
                anchor = ""
                if "#" in href:
                    href, anchor = href.split("#", 1)
                    anchor = f"#{anchor}"
                abs_path = (repo_root / href).resolve()
                return f"[{text}](file://{abs_path}{anchor})"

            content = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", rewrite_link, content)
            return {"content": content, "format": "markdown"}
    return {
        "content": "# AIStudio\n\nLocal RAG system — Apple Silicon, no cloud dependency.",
        "format": "markdown",
    }


@app.get("/howto")
async def get_howto() -> dict[str, Any]:
    """Serve HOWTO.md as a local file:// URL redirect.
    Returns the absolute path so the frontend can open it directly.
    Used by the corpus-deleted message link: see HOWTO.
    """
    repo_root = _get_repo_root()
    for fname in ["HOWTO.md", "howto.md"]:
        p = repo_root / fname
        if p.exists():
            return {"path": str(p.resolve()), "url": f"file://{p.resolve()}"}
    return {"path": "", "url": ""}


# MODEL MANAGEMENT ENDPOINTS


@app.get("/models")
async def get_models() -> list[ModelInfo]:
    """
    Get list of available LLM models from Ollama.
    """
    try:
        import ollama

        # Try to connect to Ollama and list models
        try:
            models_response = ollama.list()
            # Ollama SDK >= 0.3 returns a ListResponse object with a .models attribute
            # (list of Model objects); older versions returned a dict with 'models' key.
            if hasattr(models_response, "models"):
                ollama_models = models_response.models  # new SDK: list of Model objects
            else:
                ollama_models = models_response.get("models", [])  # old SDK: dict

            # Convert Ollama models to our format
            available_models = []
            for model in ollama_models:
                # New SDK: model is a Model object with a .model attribute (e.g. "llama3.1:8b")
                # Old SDK: model is a dict with 'name' key
                if hasattr(model, "model"):
                    full_name = model.model  # e.g. "llama3.1:8b"
                elif hasattr(model, "name"):
                    full_name = model.name
                else:
                    full_name = model.get("name", "") if isinstance(model, dict) else ""

                if not full_name:
                    continue

                # Show full name with tag for clarity (e.g. "llama3.1:8b" → "Llama3.1:8b")
                # Capitalise only the first letter to avoid "Llama3.1" vs "llama3.1" confusion
                display_name = full_name[0].upper() + full_name[1:]
                available_models.append(
                    ModelInfo(id=full_name, name=display_name, provider="Ollama", available=True)
                )

            # If we got models, return them
            if available_models:
                return available_models

        except Exception as e:
            print(f"Could not connect to Ollama: {e}")

        # Fallback: return common models with availability unknown
        return [
            ModelInfo(
                id="llama3.2:3b", name="Llama 3.2 3B", provider="Meta/Ollama", available=False
            ),
            ModelInfo(
                id="llama3.1:8b", name="Llama 3.1 8B", provider="Meta/Ollama", available=False
            ),
            ModelInfo(
                id="mistral:7b", name="Mistral 7B", provider="Mistral/Ollama", available=False
            ),
            ModelInfo(
                id="qwen2.5:7b", name="Qwen 2.5 7B", provider="Alibaba/Ollama", available=False
            ),
        ]
    except Exception as e:
        print(f"Error listing models: {e}")
        return []


@app.post("/model/select")
async def select_model(model_id: str) -> dict[str, Any]:
    """
    Select the active LLM model.
    Note: This only validates the model exists. Configuration updates would require
    updating environment variables or config files.
    """
    try:
        import ollama

        # Try to validate model exists
        try:
            models_response = ollama.list()
            ollama_models = models_response.get("models", [])
            model_names = [m.get("name", "") for m in ollama_models]

            if model_id not in model_names:
                return {
                    "status": "warning",
                    "message": f"Model '{model_id}' not found in Ollama. It may need to be pulled first.",
                    "model_id": model_id,
                    "suggestion": f"Run: ollama pull {model_id}",
                }
        except Exception as e:
            print(f"Could not verify model: {e}")

        # Mark new model as cold so next /ask triggers a fresh prewarm
        _warm_models.discard(model_id)

        return {
            "status": "info",
            "message": f"To use model '{model_id}', set environment variable: AISTUDIO_DEFAULT_MODEL={model_id}",
            "model_id": model_id,
            "current_model": CONFIG.rag.default_model,
            "note": "Restart the API server after updating environment variables",
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error selecting model: {str(e)}") from e


@app.get("/config")
async def get_config() -> dict[str, Any]:
    """
    Get current configuration including selected model, corpus, and parameters.
    """
    return {
        "current_model": CONFIG.rag.default_model,
        "current_embed_model": CONFIG.rag.default_embed_model,
        "default_corpus": "default",
        "parameters": {
            "temperature": 0.7,
            "top_k": CONFIG.rag.top_k,
            "top_p": 0.9,
        },
        "rag_config": {
            "use_chroma": CONFIG.rag.use_chroma,
            # "hybrid_enabled": CONFIG.rag.hybrid_enabled,
            # "decompose_multi_entity": CONFIG.rag.decompose_multi_entity,
            "max_distance": CONFIG.rag.max_distance,
        },
        "ingest_config": {
            "chunk_size": CONFIG.ingest.chunk_size,
            "overlap": CONFIG.ingest.overlap,
        },
    }


@app.post("/prompt/reload")
async def reload_prompt() -> dict[str, Any]:
    """
    Clear the cached system prompt and reload from prompts/system.txt.
    Allows live system prompt edits without restarting the backend.
    """
    global _SYSTEM_PROMPT_BASE
    _SYSTEM_PROMPT_BASE = None
    _load_system_prompt()
    return {"status": "ok", "prompt_length": len(_SYSTEM_PROMPT_BASE)}


@app.get("/prompt/text")
async def get_prompt_text() -> dict[str, Any]:
    """
    Return the current contents of prompts/system.txt for the Defaults modal editor.
    """
    try:
        repo_root = _get_repo_root()
        prompts_path = repo_root / "prompts" / "system.txt"
        if prompts_path.exists():
            text = prompts_path.read_text(encoding="utf-8")
            return {"prompt": text, "path": str(prompts_path)}
        return {"prompt": "", "path": str(prompts_path), "warning": "system.txt not found"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Could not read system prompt: {e}") from e


class PromptUpdateRequest(BaseModel):
    prompt: str


@app.post("/prompt/update")
async def update_prompt_text(req: PromptUpdateRequest) -> dict[str, Any]:
    """
    Write new prompt text to prompts/system.txt.
    Call POST /prompt/reload after this to activate the new prompt.
    """
    try:
        repo_root = _get_repo_root()
        prompts_path = repo_root / "prompts" / "system.txt"
        prompts_path.parent.mkdir(parents=True, exist_ok=True)
        prompts_path.write_text(req.prompt, encoding="utf-8")
        return {"status": "ok", "path": str(prompts_path), "length": len(req.prompt)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Could not write system prompt: {e}") from e


@app.get("/source")
async def serve_source(path: str, page: int | None = None) -> FileResponse:
    """
    Serve a local source document (PDF, PPTX, etc.) by absolute path.
    Replaces file:// links — works in all browsers including Safari.
    The optional page parameter is passed as a URL fragment hint in the
    response header so the browser can scroll to the cited page.
    """
    file_path = Path(path)

    # AIS_01 — cross-machine path rebase. A citation's `source` is the absolute
    # path captured at INGEST time, which may carry a different machine/user root
    # (e.g. a seed corpus ingested under /Users/<other>/.../data/corpora/...). If the
    # raw path doesn't resolve on THIS machine, re-root its "data/corpora/..." tail
    # onto the local repo. Fixes every existing payload with no re-ingest.
    if not (file_path.exists() and file_path.is_file()):
        _norm = path.replace("\\", "/")
        _marker = "data/corpora/"
        _idx = _norm.find(_marker)
        if _idx != -1:
            _rebased = _get_repo_root() / _norm[_idx:]
            if _rebased.exists() and _rebased.is_file():
                file_path = _rebased

    if not file_path.exists() or not file_path.is_file():
        raise HTTPException(status_code=404, detail=f"Source file not found: {path}")

    # Security: only serve files within known corpus/data directories
    repo = _get_repo_root()
    allowed_roots = [
        repo / "data",
        Path.home() / "Downloads",
    ]
    resolved = file_path.resolve()
    if not any(str(resolved).startswith(str(r.resolve())) for r in allowed_roots):
        raise HTTPException(status_code=403, detail="Access to this path is not permitted")

    _ext = file_path.suffix.lower()
    media_type = (
        "application/pdf" if _ext == ".pdf"
        else "text/html" if _ext in (".htm", ".html", ".xhtml")
        else "application/octet-stream"
    )

    headers = {}
    if page is not None:
        # Hint the browser to scroll to the page via Content-Disposition filename fragment
        headers["X-PDF-Page"] = str(page)

    return FileResponse(
        path=str(resolved),
        media_type=media_type,
        headers=headers,
        filename=file_path.name,
        content_disposition_type="inline",
    )
